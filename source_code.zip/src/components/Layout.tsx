import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface LayoutProps {
  children: ReactNode;
  className?: string;
  showHeader?: boolean;
  showFooter?: boolean;
  variant?: 'default' | 'centered' | 'fullscreen';
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  className = '', 
  showHeader = true, 
  showFooter = true,
  variant = 'default'
}) => {
  const getLayoutClasses = () => {
    switch (variant) {
      case 'centered':
        return 'min-h-screen flex flex-col items-center justify-center';
      case 'fullscreen':
        return 'h-screen overflow-hidden';
      default:
        return 'min-h-screen flex flex-col';
    }
  };

  return (
    <div className={`${getLayoutClasses()} ${className}`}>
      {showHeader && (
        <motion.header 
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <img src="/assets/logo.png" alt="Logo" className="h-8 w-8" />
                <span className="ml-2 text-xl font-semibold text-gray-900">TestYourself</span>
              </div>
              <nav className="hidden md:flex space-x-8">
                <a href="/" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Home</a>
                <a href="#" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Quizzes</a>
                <a href="/exam-mode" className="text-orange-600 hover:text-orange-800 px-3 py-2 rounded-md text-sm font-medium font-semibold">Exam Mode</a>
                <a href="/results-celebration" className="text-purple-600 hover:text-purple-800 px-3 py-2 rounded-md text-sm font-medium font-semibold">Results</a>
                <a href="/detailed-analytics" className="text-blue-600 hover:text-blue-800 px-3 py-2 rounded-md text-sm font-medium font-semibold">Analytics</a>
                <a href="/profile" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Profile</a>
                <a href="/settings" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Settings</a>
              </nav>
            </div>
          </div>
        </motion.header>
      )}

      <main className="flex-1 w-full">
        {children}
      </main>

      {showFooter && (
        <motion.footer 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-gray-50 border-t border-gray-200"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-4">TestYourself</h3>
                <p className="text-gray-600 text-sm">Challenge your knowledge with interactive quizzes and assessments.</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Home</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Quizzes</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Leaderboard</a></li>
                  <li><a href="#" className="text-gray-600 hover:text-gray-900 text-sm">Support</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-4">Connect</h3>
                <div className="flex space-x-4">
                  <button className="text-gray-400 hover:text-gray-600">
                    <span className="text-lg">📱</span>
                  </button>
                  <button className="text-gray-400 hover:text-gray-600">
                    <span className="text-lg">💌</span>
                  </button>
                  <button className="text-gray-400 hover:text-gray-600">
                    <span className="text-lg">🌐</span>
                  </button>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t border-gray-200">
              <p className="text-center text-gray-400 text-sm">© 2025 TestYourself. All rights reserved.</p>
            </div>
          </div>
        </motion.footer>
      )}
    </div>
  );
};

export default Layout;