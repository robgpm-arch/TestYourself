import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser,
  GoogleAuthProvider,
  FacebookAuthProvider
} from 'firebase/auth';
import { doc, setDoc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, googleProvider, facebookProvider } from '../config/firebase';
import { User, UserProfile, UserPreferences, UserStats, COLLECTIONS } from '../types/firebase';

export class AuthService {
  /**
   * Sign in with email and password
   */
  static async signInWithEmail(email: string, password: string): Promise<User> {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userData = await this.getUserData(userCredential.user.uid);
      
      // Update last login time
      await this.updateLastLogin(userCredential.user.uid);
      
      return userData;
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  }

  /**
   * Sign up with email and password
   */
  static async signUpWithEmail(
    email: string, 
    password: string, 
    displayName: string
  ): Promise<User> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      
      // Update display name
      await updateProfile(userCredential.user, { displayName });
      
      // Create user document in Firestore
      const userData = await this.createUserDocument(userCredential.user, { displayName });
      
      // Send email verification
      await sendEmailVerification(userCredential.user);
      
      return userData;
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  }

  /**
   * Sign in with Google
   */
  static async signInWithGoogle(): Promise<User> {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      
      // Check if user document exists, create if not
      let userData = await this.getUserData(user.uid);
      if (!userData) {
        userData = await this.createUserDocument(user);
      }
      
      // Update last login time
      await this.updateLastLogin(user.uid);
      
      return userData;
    } catch (error) {
      console.error('Google sign in error:', error);
      throw error;
    }
  }

  /**
   * Sign in with Facebook
   */
  static async signInWithFacebook(): Promise<User> {
    try {
      const result = await signInWithPopup(auth, facebookProvider);
      const user = result.user;
      
      // Check if user document exists, create if not
      let userData = await this.getUserData(user.uid);
      if (!userData) {
        userData = await this.createUserDocument(user);
      }
      
      // Update last login time
      await this.updateLastLogin(user.uid);
      
      return userData;
    } catch (error) {
      console.error('Facebook sign in error:', error);
      throw error;
    }
  }

  /**
   * Sign out current user
   */
  static async signOutUser(): Promise<void> {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Sign out error:', error);
      throw error;
    }
  }

  /**
   * Send password reset email
   */
  static async resetPassword(email: string): Promise<void> {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  }

  /**
   * Send email verification to current user
   */
  static async sendVerificationEmail(): Promise<void> {
    const user = auth.currentUser;
    if (!user) throw new Error('No authenticated user');
    
    try {
      await sendEmailVerification(user);
    } catch (error) {
      console.error('Email verification error:', error);
      throw error;
    }
  }

  /**
   * Get current authenticated user
   */
  static getCurrentUser(): FirebaseUser | null {
    return auth.currentUser;
  }

  /**
   * Listen to auth state changes
   */
  static onAuthStateChange(callback: (user: User | null) => void): () => void {
    return onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userData = await this.getUserData(firebaseUser.uid);
          callback(userData);
        } catch (error) {
          console.error('Error fetching user data:', error);
          callback(null);
        }
      } else {
        callback(null);
      }
    });
  }

  /**
   * Create user document in Firestore
   */
  private static async createUserDocument(
    firebaseUser: FirebaseUser, 
    additionalData: any = {}
  ): Promise<User> {
    const now = serverTimestamp();
    
    const defaultProfile: UserProfile = {
      firstName: additionalData.displayName?.split(' ')[0] || '',
      lastName: additionalData.displayName?.split(' ')[1] || '',
      achievements: [],
      badges: []
    };

    const defaultPreferences: UserPreferences = {
      theme: 'system',
      language: 'en',
      notifications: {
        email: true,
        push: true,
        inApp: true,
        reminders: true,
        achievements: true,
        social: true
      },
      privacy: {
        profileVisibility: 'public',
        showStats: true,
        showProgress: true,
        allowFriendRequests: true
      },
      gameSettings: {
        soundEffects: true,
        backgroundMusic: true,
        vibration: true,
        autoSubmit: false,
        showHints: true
      }
    };

    const defaultStats: UserStats = {
      totalQuizzesCompleted: 0,
      totalQuestionsAnswered: 0,
      correctAnswers: 0,
      accuracy: 0,
      totalTimeSpent: 0,
      streakCurrent: 0,
      streakBest: 0,
      level: 1,
      experiencePoints: 0,
      favoriteSubjects: [],
      averageScore: 0
    };

    const userData: User = {
      uid: firebaseUser.uid,
      email: firebaseUser.email!,
      displayName: firebaseUser.displayName || additionalData.displayName || '',
      photoURL: firebaseUser.photoURL,
      phoneNumber: firebaseUser.phoneNumber,
      emailVerified: firebaseUser.emailVerified,
      createdAt: now,
      updatedAt: now,
      lastLoginAt: now,
      profile: defaultProfile,
      preferences: defaultPreferences,
      stats: defaultStats,
      ...additionalData
    };

    await setDoc(doc(db, COLLECTIONS.USERS, firebaseUser.uid), userData);
    return userData;
  }

  /**
   * Get user data from Firestore
   */
  private static async getUserData(uid: string): Promise<User | null> {
    try {
      const userDoc = await getDoc(doc(db, COLLECTIONS.USERS, uid));
      if (userDoc.exists()) {
        return userDoc.data() as User;
      }
      return null;
    } catch (error) {
      console.error('Error fetching user data:', error);
      return null;
    }
  }

  /**
   * Update user's last login time
   */
  private static async updateLastLogin(uid: string): Promise<void> {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, uid), {
        lastLoginAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating last login:', error);
    }
  }

  /**
   * Update user profile
   */
  static async updateUserProfile(uid: string, profileData: Partial<UserProfile>): Promise<void> {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, uid), {
        profile: profileData,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }

  /**
   * Update user preferences
   */
  static async updateUserPreferences(uid: string, preferences: Partial<UserPreferences>): Promise<void> {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, uid), {
        preferences: preferences,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating user preferences:', error);
      throw error;
    }
  }
}

export default AuthService;