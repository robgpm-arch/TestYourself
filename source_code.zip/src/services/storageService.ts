import {
  ref,
  uploadBytes,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  listAll,
  UploadTask,
  UploadTaskSnapshot
} from 'firebase/storage';
import { storage } from '../config/firebase';

export interface UploadProgress {
  progress: number;
  bytesTransferred: number;
  totalBytes: number;
}

export interface UploadResult {
  url: string;
  path: string;
  metadata: any;
}

export class StorageService {
  /**
   * Upload a file with progress tracking
   */
  static uploadFile(
    file: File,
    path: string,
    onProgress?: (progress: UploadProgress) => void,
    onComplete?: (result: UploadResult) => void,
    onError?: (error: Error) => void
  ): UploadTask {
    const storageRef = ref(storage, path);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on(
      'state_changed',
      (snapshot: UploadTaskSnapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        if (onProgress) {
          onProgress({
            progress,
            bytesTransferred: snapshot.bytesTransferred,
            totalBytes: snapshot.totalBytes
          });
        }
      },
      (error) => {
        console.error('Upload error:', error);
        if (onError) onError(error);
      },
      async () => {
        try {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          const result: UploadResult = {
            url: downloadURL,
            path: uploadTask.snapshot.ref.fullPath,
            metadata: uploadTask.snapshot.metadata
          };
          if (onComplete) onComplete(result);
        } catch (error) {
          console.error('Error getting download URL:', error);
          if (onError) onError(error as Error);
        }
      }
    );

    return uploadTask;
  }

  /**
   * Upload a file without progress tracking
   */
  static async uploadFileSimple(file: File, path: string): Promise<UploadResult> {
    try {
      const storageRef = ref(storage, path);
      const snapshot = await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(snapshot.ref);
      
      return {
        url: downloadURL,
        path: snapshot.ref.fullPath,
        metadata: snapshot.metadata
      };
    } catch (error) {
      console.error('Simple upload error:', error);
      throw error;
    }
  }

  /**
   * Upload user profile image
   */
  static uploadProfileImage(
    userId: string,
    file: File,
    onProgress?: (progress: UploadProgress) => void
  ): Promise<UploadResult> {
    return new Promise((resolve, reject) => {
      const path = `users/${userId}/profile/${Date.now()}_${file.name}`;
      
      this.uploadFile(
        file,
        path,
        onProgress,
        (result) => resolve(result),
        (error) => reject(error)
      );
    });
  }

  /**
   * Upload quiz media (images, videos, audio)
   */
  static uploadQuizMedia(
    quizId: string,
    file: File,
    mediaType: 'image' | 'video' | 'audio',
    onProgress?: (progress: UploadProgress) => void
  ): Promise<UploadResult> {
    return new Promise((resolve, reject) => {
      const path = `quizzes/${quizId}/${mediaType}/${Date.now()}_${file.name}`;
      
      this.uploadFile(
        file,
        path,
        onProgress,
        (result) => resolve(result),
        (error) => reject(error)
      );
    });
  }

  /**
   * Upload study material files
   */
  static uploadStudyMaterial(
    materialId: string,
    file: File,
    fileType: 'document' | 'video' | 'audio' | 'image',
    onProgress?: (progress: UploadProgress) => void
  ): Promise<UploadResult> {
    return new Promise((resolve, reject) => {
      const path = `study-materials/${materialId}/${fileType}/${Date.now()}_${file.name}`;
      
      this.uploadFile(
        file,
        path,
        onProgress,
        (result) => resolve(result),
        (error) => reject(error)
      );
    });
  }

  /**
   * Upload app assets (icons, splash screens, etc.)
   */
  static uploadAppAsset(
    assetType: string,
    file: File,
    fileName?: string
  ): Promise<UploadResult> {
    return new Promise((resolve, reject) => {
      const name = fileName || `${Date.now()}_${file.name}`;
      const path = `assets/${assetType}/${name}`;
      
      this.uploadFile(
        file,
        path,
        undefined,
        (result) => resolve(result),
        (error) => reject(error)
      );
    });
  }

  /**
   * Get download URL for a file
   */
  static async getDownloadUrl(filePath: string): Promise<string> {
    try {
      const storageRef = ref(storage, filePath);
      return await getDownloadURL(storageRef);
    } catch (error) {
      console.error('Error getting download URL:', error);
      throw error;
    }
  }

  /**
   * Delete a file from storage
   */
  static async deleteFile(filePath: string): Promise<void> {
    try {
      const storageRef = ref(storage, filePath);
      await deleteObject(storageRef);
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  }

  /**
   * List all files in a directory
   */
  static async listFiles(directoryPath: string): Promise<string[]> {
    try {
      const storageRef = ref(storage, directoryPath);
      const result = await listAll(storageRef);
      
      const urls = await Promise.all(
        result.items.map(async (item) => {
          return await getDownloadURL(item);
        })
      );
      
      return urls;
    } catch (error) {
      console.error('Error listing files:', error);
      return [];
    }
  }

  /**
   * Upload multiple files
   */
  static async uploadMultipleFiles(
    files: File[],
    basePath: string,
    onProgress?: (fileIndex: number, progress: UploadProgress) => void
  ): Promise<UploadResult[]> {
    const uploadPromises = files.map((file, index) => {
      return new Promise<UploadResult>((resolve, reject) => {
        const path = `${basePath}/${Date.now()}_${index}_${file.name}`;
        
        this.uploadFile(
          file,
          path,
          (progress) => {
            if (onProgress) onProgress(index, progress);
          },
          (result) => resolve(result),
          (error) => reject(error)
        );
      });
    });

    try {
      return await Promise.all(uploadPromises);
    } catch (error) {
      console.error('Error uploading multiple files:', error);
      throw error;
    }
  }

  /**
   * Create a compressed image upload
   */
  static async uploadCompressedImage(
    file: File,
    path: string,
    maxWidth: number = 800,
    quality: number = 0.8,
    onProgress?: (progress: UploadProgress) => void
  ): Promise<UploadResult> {
    try {
      const compressedFile = await this.compressImage(file, maxWidth, quality);
      
      return new Promise((resolve, reject) => {
        this.uploadFile(
          compressedFile,
          path,
          onProgress,
          (result) => resolve(result),
          (error) => reject(error)
        );
      });
    } catch (error) {
      console.error('Error uploading compressed image:', error);
      throw error;
    }
  }

  /**
   * Compress an image file
   */
  private static compressImage(
    file: File,
    maxWidth: number = 800,
    quality: number = 0.8
  ): Promise<File> {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        // Calculate new dimensions
        const ratio = Math.min(maxWidth / img.width, maxWidth / img.height);
        const width = img.width * ratio;
        const height = img.height * ratio;

        // Set canvas dimensions
        canvas.width = width;
        canvas.height = height;

        // Draw and compress
        ctx?.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const compressedFile = new File([blob], file.name, {
                type: file.type,
                lastModified: Date.now()
              });
              resolve(compressedFile);
            } else {
              reject(new Error('Failed to compress image'));
            }
          },
          file.type,
          quality
        );
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = URL.createObjectURL(file);
    });
  }

  /**
   * Get file size in human readable format
   */
  static formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Validate file type and size
   */
  static validateFile(
    file: File,
    allowedTypes: string[],
    maxSizeInMB: number = 10
  ): { isValid: boolean; error?: string } {
    // Check file type
    if (!allowedTypes.includes(file.type)) {
      return {
        isValid: false,
        error: `File type ${file.type} is not allowed. Allowed types: ${allowedTypes.join(', ')}`
      };
    }

    // Check file size
    const maxSizeInBytes = maxSizeInMB * 1024 * 1024;
    if (file.size > maxSizeInBytes) {
      return {
        isValid: false,
        error: `File size (${this.formatFileSize(file.size)}) exceeds maximum allowed size (${maxSizeInMB}MB)`
      };
    }

    return { isValid: true };
  }

  /**
   * Generate unique file path
   */
  static generateFilePath(
    directory: string,
    fileName: string,
    userId?: string
  ): string {
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const userPrefix = userId ? `${userId}/` : '';
    
    return `${directory}/${userPrefix}${timestamp}_${randomString}_${fileName}`;
  }
}

export default StorageService;