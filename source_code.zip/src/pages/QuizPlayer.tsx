import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';

interface QuizOption {
  id: string;
  text: string;
  letter: 'A' | 'B' | 'C' | 'D';
}

interface QuizQuestion {
  id: string;
  text: string;
  options: QuizOption[];
  image?: string;
  explanation?: string;
  correctAnswer: string;
}

interface QuizAnswer {
  questionId: string;
  selectedOption: string;
  isMarkedForReview: boolean;
  timeSpent: number;
}

interface QuizState {
  currentQuestion: number;
  answers: QuizAnswer[];
  timeRemaining: number;
  isCompleted: boolean;
}

const QuizPlayer: React.FC = () => {
  const navigate = useNavigate();
  
  // Sample quiz data
  const quizData = {
    title: "Science – Chapter 2",
    totalQuestions: 20,
    timeLimit: 30 * 60, // 30 minutes in seconds
    questions: [
      {
        id: 'q1',
        text: 'What is the chemical symbol for gold?',
        options: [
          { id: 'a', text: 'Go', letter: 'A' as const },
          { id: 'b', text: 'Au', letter: 'B' as const },
          { id: 'c', text: 'Ag', letter: 'C' as const },
          { id: 'd', text: 'Al', letter: 'D' as const }
        ],
        correctAnswer: 'b'
      },
      {
        id: 'q2',
        text: 'Which of the following is NOT a renewable energy source?',
        options: [
          { id: 'a', text: 'Solar Power', letter: 'A' as const },
          { id: 'b', text: 'Wind Power', letter: 'B' as const },
          { id: 'c', text: 'Coal', letter: 'C' as const },
          { id: 'd', text: 'Hydroelectric Power', letter: 'D' as const }
        ],
        correctAnswer: 'c'
      },
      {
        id: 'q3', 
        text: 'What is the process by which plants make their own food using sunlight?',
        options: [
          { id: 'a', text: 'Respiration', letter: 'A' as const },
          { id: 'b', text: 'Photosynthesis', letter: 'B' as const },
          { id: 'c', text: 'Digestion', letter: 'C' as const },
          { id: 'd', text: 'Transpiration', letter: 'D' as const }
        ],
        correctAnswer: 'b'
      },
      {
        id: 'q4',
        text: 'What is the largest planet in our solar system?',
        options: [
          { id: 'a', text: 'Earth', letter: 'A' as const },
          { id: 'b', text: 'Saturn', letter: 'B' as const },
          { id: 'c', text: 'Jupiter', letter: 'C' as const },
          { id: 'd', text: 'Neptune', letter: 'D' as const }
        ],
        correctAnswer: 'c'
      },
      {
        id: 'q5',
        text: 'Which gas makes up approximately 78% of Earth\'s atmosphere?',
        options: [
          { id: 'a', text: 'Oxygen', letter: 'A' as const },
          { id: 'b', text: 'Carbon Dioxide', letter: 'B' as const },
          { id: 'c', text: 'Nitrogen', letter: 'C' as const },
          { id: 'd', text: 'Argon', letter: 'D' as const }
        ],
        correctAnswer: 'c'
      }
    ]
  };

  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestion: 0,
    answers: [],
    timeRemaining: quizData.timeLimit,
    isCompleted: false
  });

  const [showSideNav, setShowSideNav] = useState(false);

  // Timer countdown
  useEffect(() => {
    if (quizState.timeRemaining > 0 && !quizState.isCompleted) {
      const timer = setTimeout(() => {
        setQuizState(prev => ({
          ...prev,
          timeRemaining: prev.timeRemaining - 1
        }));
      }, 1000);
      return () => clearTimeout(timer);
    } else if (quizState.timeRemaining === 0) {
      // Auto-submit when time runs out
      handleQuizComplete();
    }
  }, [quizState.timeRemaining, quizState.isCompleted]);

  const currentQuestion = quizData.questions[quizState.currentQuestion];
  const currentAnswer = quizState.answers.find(a => a.questionId === currentQuestion?.id);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getOptionColor = (letter: 'A' | 'B' | 'C' | 'D') => {
    const colors = {
      A: 'bg-blue-500 hover:bg-blue-600',
      B: 'bg-green-500 hover:bg-green-600', 
      C: 'bg-orange-500 hover:bg-orange-600',
      D: 'bg-purple-500 hover:bg-purple-600'
    };
    return colors[letter];
  };

  const getGlowColor = (letter: 'A' | 'B' | 'C' | 'D') => {
    const colors = {
      A: 'shadow-blue-500/50',
      B: 'shadow-green-500/50',
      C: 'shadow-orange-500/50', 
      D: 'shadow-purple-500/50'
    };
    return colors[letter];
  };

  const handleOptionSelect = (optionId: string) => {
    setQuizState(prev => {
      const newAnswers = prev.answers.filter(a => a.questionId !== currentQuestion.id);
      newAnswers.push({
        questionId: currentQuestion.id,
        selectedOption: optionId,
        isMarkedForReview: currentAnswer?.isMarkedForReview || false,
        timeSpent: 0
      });
      
      return {
        ...prev,
        answers: newAnswers
      };
    });
  };

  const handleMarkForReview = () => {
    setQuizState(prev => {
      const newAnswers = [...prev.answers];
      const existingIndex = newAnswers.findIndex(a => a.questionId === currentQuestion.id);
      
      if (existingIndex >= 0) {
        newAnswers[existingIndex].isMarkedForReview = !newAnswers[existingIndex].isMarkedForReview;
      } else {
        newAnswers.push({
          questionId: currentQuestion.id,
          selectedOption: '',
          isMarkedForReview: true,
          timeSpent: 0
        });
      }
      
      return {
        ...prev,
        answers: newAnswers
      };
    });
  };

  const handlePrevious = () => {
    if (quizState.currentQuestion > 0) {
      setQuizState(prev => ({
        ...prev,
        currentQuestion: prev.currentQuestion - 1
      }));
    }
  };

  const handleNext = () => {
    if (quizState.currentQuestion < quizData.questions.length - 1) {
      setQuizState(prev => ({
        ...prev,
        currentQuestion: prev.currentQuestion + 1
      }));
    } else {
      handleQuizComplete();
    }
  };

  const handleQuizComplete = () => {
    setQuizState(prev => ({ ...prev, isCompleted: true }));
    // In real app, this would submit answers and navigate to results
    console.log('Quiz completed!', quizState.answers);
  };

  const jumpToQuestion = (questionIndex: number) => {
    setQuizState(prev => ({
      ...prev,
      currentQuestion: questionIndex
    }));
    setShowSideNav(false);
  };

  const getQuestionStatus = (questionIndex: number) => {
    const question = quizData.questions[questionIndex];
    const answer = quizState.answers.find(a => a.questionId === question.id);
    
    if (answer?.isMarkedForReview) return 'marked';
    if (answer?.selectedOption) return 'answered';
    return 'unanswered';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'answered': return 'bg-green-500';
      case 'marked': return 'bg-purple-500';
      default: return 'bg-gray-400';
    }
  };

  // Calculate progress
  const answeredQuestions = quizState.answers.filter(a => a.selectedOption).length;
  const progressPercentage = (answeredQuestions / quizData.totalQuestions) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-400 via-teal-200 to-white relative overflow-hidden">
      {/* Background dotted grid pattern */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'radial-gradient(circle, #374151 1px, transparent 1px)',
          backgroundSize: '20px 20px'
        }}
      />

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Top Bar */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-sm border-b border-teal-200 p-4"
        >
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            {/* Quiz Title */}
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-bold text-gray-800">{quizData.title}</h1>
              <button
                onClick={() => setShowSideNav(!showSideNav)}
                className="lg:hidden p-2 text-teal-600 hover:bg-teal-50 rounded-lg"
              >
                ☰
              </button>
            </div>

            {/* Progress and Timer */}
            <div className="flex items-center space-x-6">
              {/* Progress */}
              <div className="text-sm text-gray-600">
                Q {quizState.currentQuestion + 1}/{quizData.totalQuestions}
              </div>

              {/* Timer */}
              <div className="flex items-center space-x-2">
                <div className="relative w-10 h-10">
                  <svg className="w-10 h-10 transform -rotate-90">
                    <circle
                      cx="20"
                      cy="20"
                      r="16"
                      stroke="#fee2e2"
                      strokeWidth="3"
                      fill="none"
                    />
                    <motion.circle
                      cx="20"
                      cy="20"
                      r="16"
                      stroke="#ef4444"
                      strokeWidth="3"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 16}`}
                      initial={{ strokeDashoffset: 0 }}
                      animate={{ 
                        strokeDashoffset: (1 - quizState.timeRemaining / quizData.timeLimit) * 2 * Math.PI * 16
                      }}
                      transition={{ duration: 0.5 }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs text-red-600">⏱️</span>
                  </div>
                </div>
                <div className="text-sm font-mono text-red-600">
                  {formatTime(quizState.timeRemaining)}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="flex-1 flex">
          {/* Side Navigator - Desktop */}
          <div className="hidden lg:block w-20 p-4">
            <div className="sticky top-4">
              <div className="grid grid-cols-2 gap-2">
                {quizData.questions.map((_, index) => {
                  const status = getQuestionStatus(index);
                  return (
                    <motion.button
                      key={index}
                      onClick={() => jumpToQuestion(index)}
                      className={`w-8 h-8 rounded-full text-xs font-semibold text-white transition-all duration-200 ${
                        getStatusColor(status)
                      } ${
                        index === quizState.currentQuestion ? 'ring-2 ring-teal-500 ring-offset-2' : ''
                      }`}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {index + 1}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Question Area */}
          <div className="flex-1 p-4 pb-24">
            <div className="max-w-4xl mx-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={quizState.currentQuestion}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Question Card */}
                  <Card variant="elevated" className="mb-6">
                    <div className="p-6">
                      <h2 className="text-xl font-bold text-blue-900 mb-4 leading-relaxed">
                        {currentQuestion?.text}
                      </h2>
                      
                      {/* Question Image (if available) */}
                      {currentQuestion?.image && (
                        <div className="mb-6">
                          <img 
                            src={currentQuestion.image} 
                            alt="Question diagram"
                            className="max-w-full h-auto rounded-lg shadow-md"
                          />
                        </div>
                      )}
                    </div>
                  </Card>

                  {/* Options */}
                  <div className="grid gap-4 md:grid-cols-2">
                    {currentQuestion?.options.map((option) => {
                      const isSelected = currentAnswer?.selectedOption === option.id;
                      return (
                        <motion.div
                          key={option.id}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Card
                            variant="default"
                            className={`cursor-pointer transition-all duration-200 ${
                              isSelected 
                                ? `ring-4 ring-white ring-opacity-75 shadow-2xl ${getGlowColor(option.letter)}` 
                                : 'hover:shadow-lg'
                            }`}
                            onClick={() => handleOptionSelect(option.id)}
                          >
                            <div className={`${getOptionColor(option.letter)} text-white font-bold text-center p-4 rounded-xl transition-all duration-200`}>
                              <div className="flex items-center justify-center space-x-3">
                                <span className="text-lg">{option.letter}</span>
                                <span className="flex-1 text-left">{option.text}</span>
                                {isSelected && (
                                  <motion.span
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    className="text-xl"
                                  >
                                    ✅
                                  </motion.span>
                                )}
                              </div>
                            </div>
                          </Card>
                        </motion.div>
                      );
                    })}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Mobile Side Navigator */}
        <AnimatePresence>
          {showSideNav && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="lg:hidden fixed inset-0 bg-black/50 z-50"
              onClick={() => setShowSideNav(false)}
            >
              <motion.div
                initial={{ x: -300 }}
                animate={{ x: 0 }}
                exit={{ x: -300 }}
                className="bg-white w-80 h-full p-6 overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <h3 className="text-lg font-semibold mb-4">Questions</h3>
                <div className="grid grid-cols-5 gap-3">
                  {quizData.questions.map((_, index) => {
                    const status = getQuestionStatus(index);
                    return (
                      <button
                        key={index}
                        onClick={() => jumpToQuestion(index)}
                        className={`w-12 h-12 rounded-full text-sm font-semibold text-white transition-all duration-200 ${
                          getStatusColor(status)
                        } ${
                          index === quizState.currentQuestion ? 'ring-2 ring-teal-500 ring-offset-2' : ''
                        }`}
                      >
                        {index + 1}
                      </button>
                    );
                  })}
                </div>
                
                {/* Legend */}
                <div className="mt-6 space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                    <span>Answered</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
                    <span>Marked for Review</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-gray-400 rounded-full"></div>
                    <span>Not Answered</span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-teal-200 p-4"
        >
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            {/* Previous Button */}
            <Button
              onClick={handlePrevious}
              disabled={quizState.currentQuestion === 0}
              variant="outline"
              className="border-teal-300 text-teal-700 hover:bg-teal-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              ← Previous
            </Button>

            {/* Mark for Review */}
            <Button
              onClick={handleMarkForReview}
              variant="secondary"
              className={`${
                currentAnswer?.isMarkedForReview 
                  ? 'bg-purple-600 text-white hover:bg-purple-700' 
                  : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
              } rounded-full px-6`}
            >
              {currentAnswer?.isMarkedForReview ? '★ Marked' : '☆ Mark for Review'}
            </Button>

            {/* Next Button */}
            <Button
              onClick={handleNext}
              variant="primary"
              className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white"
            >
              {quizState.currentQuestion === quizData.questions.length - 1 ? 'Finish Quiz' : 'Next →'}
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="mt-3 max-w-6xl mx-auto">
            <div className="flex justify-between text-xs text-gray-600 mb-1">
              <span>Progress</span>
              <span>{answeredQuestions}/{quizData.totalQuestions} answered</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <motion.div
                className="bg-gradient-to-r from-teal-500 to-teal-600 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercentage}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default QuizPlayer;