import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface BoardExamOption {
  id: string;
  name: string;
  tagline: string;
  category: 'board' | 'exam';
  icon: string;
  color: string;
  searchTerms: string[];
}

const boardExamOptions: BoardExamOption[] = [
  // Boards
  {
    id: 'cbse',
    name: 'CBSE',
    tagline: 'Classes 1-12 • Central Board',
    category: 'board',
    icon: '📚',
    color: 'from-blue-500 to-blue-600',
    searchTerms: ['cbse', 'central', 'board', 'class', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
  },
  {
    id: 'icse',
    name: 'ICSE',
    tagline: 'Classes 1-10 • Council Exams',
    category: 'board',
    icon: '🎓',
    color: 'from-purple-500 to-purple-600',
    searchTerms: ['icse', 'council', 'indian', 'certificate', 'school', 'examination']
  },
  {
    id: 'isc',
    name: 'ISC',
    tagline: 'Classes 11-12 • Science & Commerce',
    category: 'board',
    icon: '🔬',
    color: 'from-indigo-500 to-indigo-600',
    searchTerms: ['isc', 'indian', 'school', 'certificate', '11', '12', 'science', 'commerce']
  },
  {
    id: 'iit-foundation',
    name: 'IIT Foundation',
    tagline: 'Classes 6-10 • Engineering Prep',
    category: 'board',
    icon: '⚙️',
    color: 'from-orange-500 to-red-500',
    searchTerms: ['iit', 'foundation', 'engineering', 'preparation', '6', '7', '8', '9', '10']
  },
  {
    id: 'ts-board',
    name: 'TS Board',
    tagline: 'Telangana State Board',
    category: 'board',
    icon: '🏛️',
    color: 'from-teal-500 to-cyan-500',
    searchTerms: ['telangana', 'ts', 'state', 'board', 'hyderabad']
  },
  {
    id: 'ap-board',
    name: 'AP Board',
    tagline: 'Andhra Pradesh State Board',
    category: 'board',
    icon: '🌅',
    color: 'from-yellow-500 to-orange-500',
    searchTerms: ['andhra', 'pradesh', 'ap', 'state', 'board', 'amaravati']
  },
  {
    id: 'tn-board',
    name: 'TN Board',
    tagline: 'Tamil Nadu State Board',
    category: 'board',
    icon: '🏺',
    color: 'from-red-500 to-pink-500',
    searchTerms: ['tamil', 'nadu', 'tn', 'state', 'board', 'chennai']
  },
  {
    id: 'mh-board',
    name: 'Maharashtra Board',
    tagline: 'Maharashtra State Board',
    category: 'board',
    icon: '🎭',
    color: 'from-green-500 to-emerald-500',
    searchTerms: ['maharashtra', 'mh', 'state', 'board', 'mumbai', 'pune']
  },
  // Exams
  {
    id: 'jee',
    name: 'JEE',
    tagline: 'Engineering Aspirants • IIT/NIT',
    category: 'exam',
    icon: '⚛️',
    color: 'from-blue-600 to-indigo-600',
    searchTerms: ['jee', 'main', 'advanced', 'engineering', 'iit', 'nit', 'physics', 'chemistry', 'maths']
  },
  {
    id: 'neet',
    name: 'NEET',
    tagline: 'Medical Aspirants • MBBS/BDS',
    category: 'exam',
    icon: '🩺',
    color: 'from-green-600 to-teal-600',
    searchTerms: ['neet', 'medical', 'mbbs', 'bds', 'doctor', 'biology', 'physics', 'chemistry']
  },
  {
    id: 'upsc',
    name: 'UPSC',
    tagline: 'Civil Services • IAS/IPS/IFS',
    category: 'exam',
    icon: '🏛️',
    color: 'from-purple-600 to-pink-600',
    searchTerms: ['upsc', 'civil', 'services', 'ias', 'ips', 'ifs', 'government', 'officer']
  },
  {
    id: 'ssc',
    name: 'SSC',
    tagline: 'Staff Selection Commission',
    category: 'exam',
    icon: '📋',
    color: 'from-orange-600 to-red-600',
    searchTerms: ['ssc', 'staff', 'selection', 'commission', 'cgl', 'chsl', 'mts', 'government']
  },
  {
    id: 'banking',
    name: 'Banking',
    tagline: 'SBI • IBPS • RBI Grade B',
    category: 'exam',
    icon: '🏦',
    color: 'from-emerald-600 to-green-600',
    searchTerms: ['banking', 'sbi', 'ibps', 'rbi', 'clerk', 'po', 'specialist', 'officer']
  },
  {
    id: 'rrb',
    name: 'RRB',
    tagline: 'Railway Recruitment Board',
    category: 'exam',
    icon: '🚂',
    color: 'from-gray-600 to-slate-600',
    searchTerms: ['rrb', 'railway', 'recruitment', 'board', 'ntpc', 'group', 'alp', 'technician']
  },
  {
    id: 'dsc-tet',
    name: 'DSC/TET',
    tagline: 'Teaching Eligibility Test',
    category: 'exam',
    icon: '👨‍🏫',
    color: 'from-cyan-600 to-blue-600',
    searchTerms: ['dsc', 'tet', 'teacher', 'teaching', 'eligibility', 'test', 'education', 'school']
  },
  {
    id: 'gate',
    name: 'GATE',
    tagline: 'Graduate Aptitude Test',
    category: 'exam',
    icon: '🎯',
    color: 'from-violet-600 to-purple-600',
    searchTerms: ['gate', 'graduate', 'aptitude', 'test', 'engineering', 'mtech', 'phd']
  }
];

interface BoardExamSelectorProps {
  onSelection: (selection: string) => void;
}

const BoardExamSelector: React.FC<BoardExamSelectorProps> = ({ onSelection }) => {
  const [activeTab, setActiveTab] = useState<'board' | 'exam'>('board');
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isConfirming, setIsConfirming] = useState(false);

  const filteredOptions = useMemo(() => {
    const tabOptions = boardExamOptions.filter(option => option.category === activeTab);
    
    if (!searchQuery.trim()) return tabOptions;
    
    const query = searchQuery.toLowerCase();
    return tabOptions.filter(option => 
      option.name.toLowerCase().includes(query) ||
      option.tagline.toLowerCase().includes(query) ||
      option.searchTerms.some(term => term.toLowerCase().includes(query))
    );
  }, [activeTab, searchQuery]);

  const handleOptionSelect = (optionId: string) => {
    setSelectedOption(optionId);
    setIsConfirming(true);
    
    // Auto-hide confirmation after 2 seconds
    setTimeout(() => {
      setIsConfirming(false);
    }, 2000);
  };

  const handleContinue = () => {
    if (selectedOption) {
      onSelection(selectedOption);
    }
  };

  const selectedOptionData = boardExamOptions.find(option => option.id === selectedOption);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-indigo-700 to-indigo-900 relative overflow-hidden">
      {/* Decorative background patterns */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-20 left-20 text-6xl transform rotate-12">📚</div>
        <div className="absolute top-40 right-32 text-5xl transform -rotate-6">✏️</div>
        <div className="absolute bottom-32 left-40 text-7xl transform rotate-45">🎓</div>
        <div className="absolute bottom-20 right-20 text-4xl transform -rotate-12">📖</div>
        <div className="absolute top-1/2 left-1/4 text-3xl transform rotate-90">🖊️</div>
        <div className="absolute top-1/3 right-1/3 text-5xl transform -rotate-30">📝</div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Select Your Board or Exam
          </h1>
          <p className="text-blue-100 text-lg md:text-xl font-medium">
            Choose the path you are preparing for — you can change later
          </p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="w-full max-w-md mb-8"
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Search boards or exams..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-6 py-4 pl-12 rounded-2xl bg-white/90 backdrop-blur-sm text-gray-800 placeholder-gray-500 font-medium shadow-lg focus:outline-none focus:ring-4 focus:ring-blue-300/50 transition-all duration-300"
            />
            <svg
              className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex bg-white/10 backdrop-blur-sm rounded-2xl p-2 mb-8"
        >
          {(['board', 'exam'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`relative px-8 py-3 rounded-xl font-semibold text-lg transition-all duration-300 ${
                activeTab === tab
                  ? 'text-white bg-white/20 shadow-lg'
                  : 'text-blue-200 hover:text-white hover:bg-white/10'
              }`}
            >
              {tab === 'board' ? 'Boards' : 'Exams'}
              {activeTab === tab && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/30 to-indigo-500/30 rounded-xl"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
            </button>
          ))}
        </motion.div>

        {/* Options Grid */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: activeTab === 'board' ? -20 : 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: activeTab === 'board' ? 20 : -20 }}
          transition={{ duration: 0.4 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 w-full max-w-6xl mb-8"
        >
          <AnimatePresence mode="wait">
            {filteredOptions.map((option, index) => (
              <motion.div
                key={option.id}
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.9 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleOptionSelect(option.id)}
                className={`
                  relative cursor-pointer rounded-2xl p-6 bg-white/90 backdrop-blur-sm
                  shadow-lg hover:shadow-2xl transition-all duration-300
                  ${selectedOption === option.id 
                    ? 'ring-4 ring-teal-300 shadow-2xl bg-white scale-105' 
                    : 'hover:bg-white'
                  }
                `}
              >
                {/* Glowing border effect for selected */}
                {selectedOption === option.id && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute inset-0 rounded-2xl bg-gradient-to-r from-teal-400 to-cyan-400 opacity-20 blur-sm"
                  />
                )}

                <div className="relative z-10 text-center">
                  {/* Icon */}
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br ${option.color} mb-4 text-2xl`}>
                    <span className="text-white font-bold">
                      {option.icon}
                    </span>
                  </div>

                  {/* Name */}
                  <h3 className="text-xl font-bold text-gray-800 mb-2">
                    {option.name}
                  </h3>

                  {/* Tagline */}
                  <p className="text-sm text-gray-600 font-medium leading-tight">
                    {option.tagline}
                  </p>

                  {/* Selection indicator */}
                  {selectedOption === option.id && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -top-2 -right-2 w-8 h-8 bg-teal-500 rounded-full flex items-center justify-center"
                    >
                      <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </motion.div>
                  )}
                </div>

                {/* Card hover effect */}
                <motion.div
                  className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* No results message */}
        {filteredOptions.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-2xl font-bold text-white mb-2">No results found</h3>
            <p className="text-blue-200">Try searching with different keywords</p>
          </motion.div>
        )}

        {/* Confirmation Message */}
        <AnimatePresence>
          {isConfirming && selectedOptionData && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className="mb-8 px-6 py-3 bg-white/90 backdrop-blur-sm rounded-full shadow-lg"
            >
              <p className="text-indigo-700 font-semibold text-center">
                {selectedOptionData.name} selected!
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Continue Button */}
        <motion.button
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: selectedOption ? 1 : 0.5, y: 0 }}
          whileHover={selectedOption ? { scale: 1.05 } : {}}
          whileTap={selectedOption ? { scale: 0.98 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          onClick={handleContinue}
          disabled={!selectedOption}
          className={`
            px-12 py-4 rounded-full font-bold text-lg text-white
            bg-gradient-to-r from-teal-500 to-cyan-500
            shadow-lg hover:shadow-xl
            transition-all duration-300
            ${selectedOption 
              ? 'cursor-pointer' 
              : 'cursor-not-allowed opacity-50'
            }
          `}
        >
          Continue
        </motion.button>

        {/* Progress indicator */}
        <div className="flex space-x-2 mt-8">
          {[1, 2, 3, 4, 5].map((step, index) => (
            <div
              key={step}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                index === 4 ? 'bg-teal-500' : 'bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default BoardExamSelector;