import React, { useState } from 'react';
import logo from '../assets/logo.png';
import adminIcon from '../assets/admin-icon.png';

interface SplashScreenProps {
  onGetStarted: () => void;
  onSignIn?: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onGetStarted, onSignIn }) => {
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  
  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-blue-500 via-purple-600 to-violet-700">
      {/* Abstract Wave Background */}
      <div className="absolute inset-0">
        <svg className="absolute bottom-0 w-full h-64 opacity-30" viewBox="0 0 1200 320" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0,160L48,186.7C96,213,192,267,288,261.3C384,256,480,192,576,181.3C672,171,768,213,864,218.7C960,224,1056,192,1152,181.3L1200,176V320H1152C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320H0V160Z" fill="url(#wave1)"/>
          <defs>
            <linearGradient id="wave1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(255,255,255,0.1)" />
              <stop offset="50%" stopColor="rgba(255,255,255,0.2)" />
              <stop offset="100%" stopColor="rgba(255,255,255,0.1)" />
            </linearGradient>
          </defs>
        </svg>
        
        <svg className="absolute bottom-16 w-full h-48 opacity-20" viewBox="0 0 1200 320" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0,64L48,85.3C96,107,192,149,288,149.3C384,149,480,107,576,112C672,117,768,171,864,181.3C960,192,1056,160,1152,138.7L1200,128V320H1152C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320H0V64Z" fill="url(#wave2)"/>
          <defs>
            <linearGradient id="wave2" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(255,255,255,0.05)" />
              <stop offset="50%" stopColor="rgba(255,255,255,0.15)" />
              <stop offset="100%" stopColor="rgba(255,255,255,0.05)" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Admin Login Icon - Top Right */}
      <div className="absolute top-6 right-6 z-20">
        <button 
          onClick={() => setShowAdminLogin(!showAdminLogin)}
          className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center shadow-lg hover:bg-white/30 transition-all duration-300 hover:scale-110"
        >
          <img src={adminIcon} alt="Admin" className="w-6 h-6" />
        </button>
      </div>

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-30 px-4">
          <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-2xl">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Admin Access</h2>
              <p className="text-gray-600">Manage courses, subjects, chapters & content</p>
            </div>
            <form className="space-y-4">
              <div>
                <input
                  type="text"
                  placeholder="Admin Username"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <input
                  type="password"
                  placeholder="Admin Password"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold py-3 px-6 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg"
              >
                Access Admin Panel
              </button>
            </form>
            <button 
              onClick={() => setShowAdminLogin(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-xl font-bold"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-8">
        
        {/* Logo and App Name Section */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 mx-auto mb-4 bg-white rounded-3xl flex items-center justify-center shadow-lg p-2">
            <img src={logo} alt="TestYourself Logo" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">TestYourself</h1>
          <p className="text-lg text-blue-100 opacity-90">Challenge Your Knowledge</p>
        </div>

        {/* Center Illustration with Floating Icons */}
        <div className="relative mb-12">
          <div className="relative">
            <img 
              src="https://public.youware.com/users-website-assets/prod/a9adc6a9-2f03-4873-86f9-880d7d00e957/e44d6f08d8b644b18fbf7166e02b7ca3.jpg" 
              alt="Student studying with books"
              className="w-48 h-48 md:w-56 md:h-56 object-contain"
            />
          </div>
          
          {/* Floating Icons with Animation */}
          <div className="absolute -top-6 -left-8 animate-bounce" style={{animationDelay: '0s', animationDuration: '3s'}}>
            <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-xl">💡</span>
            </div>
          </div>
          
          <div className="absolute -top-4 right-0 animate-bounce" style={{animationDelay: '1s', animationDuration: '3s'}}>
            <div className="w-10 h-10 bg-green-400 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-lg">✅</span>
            </div>
          </div>
          
          <div className="absolute bottom-2 -right-6 animate-bounce" style={{animationDelay: '2s', animationDuration: '3s'}}>
            <div className="w-11 h-11 bg-red-400 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-lg">❓</span>
            </div>
          </div>
        </div>

        {/* Get Started Button */}
        <button 
          onClick={onGetStarted}
          className="w-full max-w-sm bg-gradient-to-r from-violet-500 to-teal-500 hover:from-violet-600 hover:to-teal-600 text-white font-bold py-4 px-8 rounded-full text-lg shadow-xl transform hover:scale-105 transition-all duration-300 mb-6"
        >
          Get Started
        </button>

        {/* Sign In Link - Enhanced Size & Boldness */}
        <p className="text-blue-100 text-xl md:text-2xl font-bold">
          Already a member?{' '}
          <button 
            onClick={onSignIn}
            className="text-white font-black text-xl md:text-2xl hover:text-yellow-200 transition-colors duration-200 underline"
          >
            Sign In
          </button>
        </p>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-4 h-4 bg-yellow-300 rounded-full opacity-70 animate-pulse"></div>
      <div className="absolute top-32 right-16 w-3 h-3 bg-pink-300 rounded-full opacity-70 animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute bottom-40 left-20 w-5 h-5 bg-cyan-300 rounded-full opacity-70 animate-pulse" style={{animationDelay: '2s'}}></div>
      <div className="absolute bottom-60 right-10 w-2 h-2 bg-green-300 rounded-full opacity-70 animate-pulse" style={{animationDelay: '0.5s'}}></div>
    </div>
  );
};

export default SplashScreen;