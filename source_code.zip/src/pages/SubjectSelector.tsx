import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Subject {
  id: string;
  name: string;
  icon: string;
  emoji: string;
  color: string;
  description: string;
  subIcon: string;
}

const subjects: Subject[] = [
  {
    id: 'mathematics',
    name: 'Mathematics',
    icon: '➗',
    emoji: '🔢',
    color: 'from-blue-400 to-blue-600',
    description: 'Numbers, Algebra, Geometry',
    subIcon: '📐'
  },
  {
    id: 'science',
    name: 'Science',
    icon: '🔬',
    emoji: '⚛️',
    color: 'from-green-400 to-green-600',
    description: 'Physics, Chemistry, Biology',
    subIcon: '🧪'
  },
  {
    id: 'history',
    name: 'History',
    icon: '📜',
    emoji: '🏛️',
    color: 'from-amber-600 to-orange-700',
    description: 'Past Events, Civilizations',
    subIcon: '⚔️'
  },
  {
    id: 'geography',
    name: 'Geography',
    icon: '🌍',
    emoji: '🗺️',
    color: 'from-cyan-400 to-teal-600',
    description: 'Earth, Maps, Climate',
    subIcon: '🧭'
  },
  {
    id: 'english',
    name: 'English',
    icon: '📖',
    emoji: '✍️',
    color: 'from-purple-400 to-purple-600',
    description: 'Language, Literature, Grammar',
    subIcon: '📝'
  },
  {
    id: 'general-knowledge',
    name: 'General Knowledge',
    icon: '🌟',
    emoji: '💡',
    color: 'from-yellow-400 to-yellow-600',
    description: 'Facts, Trivia, Current Events',
    subIcon: '🧠'
  },
  {
    id: 'reasoning',
    name: 'Reasoning',
    icon: '🧩',
    emoji: '🎯',
    color: 'from-orange-400 to-red-500',
    description: 'Logic, Puzzles, Problem Solving',
    subIcon: '⚡'
  },
  {
    id: 'current-affairs',
    name: 'Current Affairs',
    icon: '📰',
    emoji: '📡',
    color: 'from-red-400 to-pink-500',
    description: 'News, Politics, Events',
    subIcon: '📺'
  }
];

interface SubjectSelectorProps {
  onSubjectSelect: (subject: string) => void;
}

const SubjectSelector: React.FC<SubjectSelectorProps> = ({ onSubjectSelect }) => {
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [isConfirming, setIsConfirming] = useState(false);

  const handleSubjectSelect = (subjectId: string) => {
    setSelectedSubject(subjectId);
    setIsConfirming(true);
    
    // Auto-hide confirmation after 2 seconds
    setTimeout(() => {
      setIsConfirming(false);
    }, 2000);
  };

  const handleContinue = () => {
    if (selectedSubject) {
      onSubjectSelect(selectedSubject);
    }
  };

  const selectedSubjectData = subjects.find(subject => subject.id === selectedSubject);

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-400 via-teal-300 to-white relative overflow-hidden">
      {/* Decorative background subject icons */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-16 left-16 text-8xl transform rotate-12">📚</div>
        <div className="absolute top-32 right-24 text-6xl transform -rotate-6">🔬</div>
        <div className="absolute bottom-32 left-32 text-7xl transform rotate-45">🌍</div>
        <div className="absolute bottom-16 right-16 text-5xl transform -rotate-12">📐</div>
        <div className="absolute top-1/2 left-1/6 text-4xl transform rotate-90">📖</div>
        <div className="absolute top-1/4 right-1/3 text-6xl transform -rotate-30">🧩</div>
        <div className="absolute bottom-1/3 left-2/3 text-5xl transform rotate-15">💡</div>
        <div className="absolute top-2/3 right-1/4 text-4xl transform -rotate-45">📰</div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Choose a Subject
          </h1>
          <p className="text-teal-100 text-lg md:text-xl font-medium">
            Select your favorite topic to start learning
          </p>
        </motion.div>

        {/* Subject Cards Grid */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 w-full max-w-6xl mb-12"
        >
          {subjects.map((subject, index) => (
            <motion.div
              key={subject.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ 
                duration: 0.5, 
                delay: 0.3 + index * 0.1,
                type: "spring",
                stiffness: 100
              }}
              whileHover={{ 
                scale: 1.05, 
                y: -5,
                transition: { duration: 0.2 }
              }}
              whileTap={{ 
                scale: 0.98,
                transition: { duration: 0.1 }
              }}
              onClick={() => handleSubjectSelect(subject.id)}
              className={`
                relative cursor-pointer rounded-3xl p-6 aspect-square
                bg-gradient-to-br ${subject.color} text-white
                shadow-lg hover:shadow-2xl transition-all duration-300
                ${selectedSubject === subject.id 
                  ? 'ring-4 ring-white ring-opacity-60 shadow-2xl scale-105' 
                  : ''
                }
              `}
            >
              {/* Glowing border effect for selected */}
              {selectedSubject === subject.id && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute inset-0 rounded-3xl bg-white opacity-20 blur-sm"
                />
              )}

              <div className="relative z-10 text-center h-full flex flex-col justify-center">
                {/* Main Icon */}
                <div className="text-4xl md:text-5xl mb-3">
                  {subject.icon}
                </div>

                {/* Subject Name */}
                <h3 className="text-lg md:text-xl font-bold mb-2 leading-tight">
                  {subject.name}
                </h3>

                {/* Description */}
                <p className="text-xs md:text-sm opacity-90 leading-relaxed mb-3">
                  {subject.description}
                </p>

                {/* Sub Icon */}
                <div className="text-2xl md:text-3xl opacity-80">
                  {subject.subIcon}
                </div>

                {/* Selection indicator */}
                {selectedSubject === subject.id && (
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    className="absolute -top-3 -right-3 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg"
                  >
                    <svg className="w-6 h-6 text-teal-500" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </motion.div>
                )}

                {/* Hover overlay */}
                <motion.div
                  className="absolute inset-0 rounded-3xl bg-white opacity-0 hover:opacity-10 transition-opacity duration-300 pointer-events-none"
                />
              </div>

              {/* Card expansion effect */}
              {selectedSubject === subject.id && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute inset-0 rounded-3xl border-4 border-white opacity-30"
                />
              )}
            </motion.div>
          ))}
        </motion.div>

        {/* Confirmation Message */}
        <AnimatePresence>
          {isConfirming && selectedSubjectData && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className="mb-8 px-8 py-4 bg-white/95 backdrop-blur-sm rounded-full shadow-lg"
            >
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{selectedSubjectData.icon}</span>
                <p className="text-teal-700 font-bold text-lg">
                  {selectedSubjectData.name} selected!
                </p>
                <span className="text-2xl">{selectedSubjectData.emoji}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Continue Button */}
        <motion.button
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: selectedSubject ? 1 : 0.5, y: 0 }}
          whileHover={selectedSubject ? { scale: 1.05 } : {}}
          whileTap={selectedSubject ? { scale: 0.98 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          onClick={handleContinue}
          disabled={!selectedSubject}
          className={`
            px-12 py-4 rounded-full font-bold text-lg text-white
            bg-gradient-to-r from-teal-500 to-cyan-500
            shadow-lg hover:shadow-xl
            transition-all duration-300
            ${selectedSubject 
              ? 'cursor-pointer' 
              : 'cursor-not-allowed opacity-50'
            }
          `}
        >
          Continue
        </motion.button>

        {/* Fun motivational text */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-6 text-center"
        >
          <p className="text-teal-100 text-sm md:text-base font-medium">
            🚀 Ready to explore and learn something amazing?
          </p>
        </motion.div>

        {/* Progress indicator */}
        <div className="flex space-x-2 mt-8">
          {[1, 2, 3, 4, 5, 6, 7].map((step, index) => (
            <div
              key={step}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                index === 6 ? 'bg-teal-500' : 'bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubjectSelector;