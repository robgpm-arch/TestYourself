import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';

interface QuizTheme {
  id: string;
  name: string;
  description: string;
  preview: {
    question: string;
    options: string[];
    backgroundColor: string;
    questionColor: string;
    optionStyle: string;
    accentColor: string;
    pattern?: string;
  };
  features: string[];
}

const ThemePicker: React.FC = () => {
  const navigate = useNavigate();
  const [selectedTheme, setSelectedTheme] = useState<string>('classic');
  const [hoveredTheme, setHoveredTheme] = useState<string | null>(null);

  // Theme definitions with live preview data
  const themes: QuizTheme[] = [
    {
      id: 'classic',
      name: 'Classic',
      description: 'Clean and professional',
      preview: {
        question: 'What is the capital of France?',
        options: ['A) London', 'B) Berlin', 'C) Paris', 'D) Madrid'],
        backgroundColor: 'bg-white',
        questionColor: 'text-gray-800',
        optionStyle: 'bg-blue-50 border border-blue-200 text-blue-800',
        accentColor: 'text-blue-600'
      },
      features: ['Clean interface', 'High readability', 'Professional look']
    },
    {
      id: 'playful',
      name: 'Playful Kids',
      description: 'Fun and colorful for children',
      preview: {
        question: 'Which animal says "Moo"? 🐄',
        options: ['🐱 Cat', '🐄 Cow', '🐶 Dog', '🐸 Frog'],
        backgroundColor: 'bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100',
        questionColor: 'text-purple-800',
        optionStyle: 'bg-gradient-to-r from-yellow-200 to-orange-200 border-2 border-pink-300 text-purple-700 rounded-full',
        accentColor: 'text-pink-600',
        pattern: 'confetti'
      },
      features: ['Bright colors', 'Fun emojis', 'Kid-friendly fonts']
    },
    {
      id: 'dark',
      name: 'Dark Modern',
      description: 'Sleek glassmorphism design',
      preview: {
        question: 'What is 2 + 2?',
        options: ['A) 3', 'B) 4', 'C) 5', 'D) 6'],
        backgroundColor: 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900',
        questionColor: 'text-white',
        optionStyle: 'bg-white/10 backdrop-blur-md border border-cyan-400/30 text-cyan-300',
        accentColor: 'text-cyan-400'
      },
      features: ['Dark theme', 'Glassmorphism', 'Neon accents']
    },
    {
      id: 'nature',
      name: 'Nature Calm',
      description: 'Peaceful earth tones',
      preview: {
        question: 'Which process do plants use to make food?',
        options: ['A) Respiration', 'B) Photosynthesis', 'C) Digestion', 'D) Circulation'],
        backgroundColor: 'bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50',
        questionColor: 'text-green-800',
        optionStyle: 'bg-green-100 border border-green-300 text-green-800',
        accentColor: 'text-emerald-600',
        pattern: 'leaves'
      },
      features: ['Calming colors', 'Nature patterns', 'Easy on eyes']
    },
    {
      id: 'festival',
      name: 'Festival',
      description: 'Vibrant seasonal themes',
      preview: {
        question: 'Which festival is known as the Festival of Lights?',
        options: ['A) Holi', 'B) Diwali', 'C) Eid', 'D) Christmas'],
        backgroundColor: 'bg-gradient-to-br from-orange-100 via-yellow-100 to-red-100',
        questionColor: 'text-orange-900',
        optionStyle: 'bg-gradient-to-r from-yellow-200 to-orange-200 border-2 border-red-300 text-orange-800',
        accentColor: 'text-red-600',
        pattern: 'festival'
      },
      features: ['Seasonal patterns', 'Cultural themes', 'Warm colors']
    },
    {
      id: 'minimal',
      name: 'Minimal Exam',
      description: 'Distraction-free focus mode',
      preview: {
        question: 'What is the chemical symbol for gold?',
        options: ['A) Go', 'B) Au', 'C) Ag', 'D) Al'],
        backgroundColor: 'bg-gray-50',
        questionColor: 'text-black',
        optionStyle: 'bg-white border-2 border-gray-400 text-black',
        accentColor: 'text-gray-800'
      },
      features: ['High contrast', 'No distractions', 'Exam optimized']
    }
  ];

  const handleThemeSelect = (themeId: string) => {
    setSelectedTheme(themeId);
  };

  const handlePreviewFullScreen = () => {
    // In real app, this would show full-screen preview
    console.log('Preview theme:', selectedTheme);
  };

  const handleApplyTheme = () => {
    // In real app, this would save theme preference and navigate back
    console.log('Apply theme:', selectedTheme);
    localStorage.setItem('quiz_theme', selectedTheme);
    navigate(-1);
  };

  const renderThemePattern = (pattern: string | undefined, isHovered: boolean) => {
    if (!pattern) return null;

    switch (pattern) {
      case 'confetti':
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-gradient-to-r from-pink-400 to-yellow-400 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={isHovered ? {
                  scale: [1, 1.5, 1],
                  rotate: [0, 360],
                } : {}}
                transition={{
                  duration: 2,
                  repeat: isHovered ? Infinity : 0,
                  delay: Math.random() * 2
                }}
              />
            ))}
          </div>
        );
      case 'leaves':
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute text-green-400"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  fontSize: `${12 + Math.random() * 8}px`
                }}
              >
                🍃
              </div>
            ))}
          </div>
        );
      case 'festival':
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={isHovered ? {
                  scale: [1, 1.2, 1],
                  rotate: [0, 10, -10, 0],
                } : {}}
                transition={{
                  duration: 3,
                  repeat: isHovered ? Infinity : 0,
                  delay: Math.random() * 3
                }}
              >
                {['🪔', '✨', '🎆', '🎊'][Math.floor(Math.random() * 4)]}
              </motion.div>
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  const selectedThemeData = themes.find(t => t.id === selectedTheme);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-purple-300 to-teal-400 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 text-6xl">🎨</div>
        <div className="absolute top-20 right-20 text-4xl">✨</div>
        <div className="absolute bottom-20 left-20 text-5xl">🎨</div>
        <div className="absolute bottom-10 right-10 text-3xl">✨</div>
        <div className="absolute top-1/2 left-1/4 text-4xl">🎨</div>
        <div className="absolute top-1/3 right-1/4 text-5xl">✨</div>
        <div className="absolute top-2/3 left-2/3 text-3xl">🎨</div>
        <div className="absolute top-1/4 right-2/3 text-4xl">✨</div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center py-8 px-4"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Choose a Quiz Theme</h1>
          <p className="text-purple-100 text-lg">Make your quiz more fun and personal</p>
        </motion.div>

        {/* Theme Grid */}
        <div className="flex-1 px-4 pb-8">
          <div className="max-w-6xl mx-auto">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {themes.map((theme, index) => (
                <motion.div
                  key={theme.id}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  className="h-full"
                >
                  <Card
                    variant="elevated"
                    className={`h-full cursor-pointer transition-all duration-300 ${
                      selectedTheme === theme.id 
                        ? 'ring-4 ring-yellow-400 ring-opacity-75 shadow-2xl shadow-yellow-400/25' 
                        : 'hover:shadow-xl'
                    }`}
                    hover={true}
                    onClick={() => handleThemeSelect(theme.id)}
                    onMouseEnter={() => setHoveredTheme(theme.id)}
                    onMouseLeave={() => setHoveredTheme(null)}
                  >
                    <div className="p-4 h-full flex flex-col">
                      {/* Theme Header */}
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-800">{theme.name}</h3>
                          <p className="text-sm text-gray-600">{theme.description}</p>
                        </div>
                        {selectedTheme === theme.id && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center"
                          >
                            <span className="text-white text-sm">✅</span>
                          </motion.div>
                        )}
                      </div>

                      {/* Live Preview Mockup */}
                      <div className="flex-1 relative">
                        <motion.div
                          className={`${theme.preview.backgroundColor} rounded-lg p-4 h-full relative overflow-hidden`}
                          whileHover={{ scale: 1.02 }}
                          transition={{ duration: 0.2 }}
                        >
                          {renderThemePattern(theme.preview.pattern, hoveredTheme === theme.id)}
                          
                          <div className="relative z-10">
                            {/* Mock Question */}
                            <div className={`${theme.preview.questionColor} font-medium text-sm mb-4`}>
                              Q1. {theme.preview.question}
                            </div>

                            {/* Mock Options */}
                            <div className="space-y-2">
                              {theme.preview.options.map((option, optionIndex) => (
                                <motion.div
                                  key={optionIndex}
                                  className={`${theme.preview.optionStyle} p-2 rounded text-xs cursor-pointer transition-colors duration-200`}
                                  whileHover={{ 
                                    scale: 1.02,
                                    backgroundColor: theme.id === 'playful' ? '#fef3c7' : undefined
                                  }}
                                  transition={{ duration: 0.1 }}
                                >
                                  {option}
                                </motion.div>
                              ))}
                            </div>

                            {/* Mock Progress */}
                            <div className="mt-4 flex items-center justify-between text-xs">
                              <span className={theme.preview.accentColor}>Question 1 of 10</span>
                              <div className="w-16 h-1 bg-gray-300 rounded-full overflow-hidden">
                                <motion.div
                                  className="h-full bg-current rounded-full"
                                  initial={{ width: 0 }}
                                  animate={{ width: '10%' }}
                                  transition={{ delay: 0.5, duration: 0.8 }}
                                  style={{ color: theme.preview.accentColor.replace('text-', '') }}
                                />
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      </div>

                      {/* Theme Features */}
                      <div className="mt-4 pt-3 border-t border-gray-200">
                        <div className="flex flex-wrap gap-1">
                          {theme.features.map((feature, featureIndex) => (
                            <span
                              key={featureIndex}
                              className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs"
                            >
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="bg-white/80 backdrop-blur-sm border-t border-purple-200 p-6"
        >
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              {/* Preview Button */}
              <Button
                onClick={handlePreviewFullScreen}
                variant="outline"
                size="large"
                className="border-purple-300 text-purple-700 hover:bg-purple-50 min-w-[180px]"
              >
                👁️ Preview in Full Screen
              </Button>

              {/* Apply Button */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  onClick={handleApplyTheme}
                  variant="primary"
                  size="large"
                  className="bg-gradient-to-r from-teal-500 to-purple-600 hover:from-teal-600 hover:to-purple-700 text-white shadow-lg min-w-[160px] relative overflow-hidden"
                >
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-teal-400 to-purple-500 opacity-0"
                    whileHover={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                  <span className="relative z-10 flex items-center justify-center">
                    ✨ Apply Theme
                  </span>
                </Button>
              </motion.div>
            </div>

            {/* Selected Theme Info */}
            <AnimatePresence mode="wait">
              {selectedThemeData && (
                <motion.div
                  key={selectedTheme}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-center mt-4"
                >
                  <p className="text-sm text-purple-700">
                    Selected: <span className="font-semibold">{selectedThemeData.name}</span> - {selectedThemeData.description}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ThemePicker;