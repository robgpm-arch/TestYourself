import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';

interface Slide {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  illustration: string;
  bgGradient: string;
}

const slides: Slide[] = [
  {
    id: 1,
    title: "Learn in Your Own Language",
    subtitle: "Multi-language support",
    description: "Access educational content in multiple languages and learn at your own pace, anywhere you are.",
    illustration: "https://public.youware.com/users-website-assets/prod/a9adc6a9-2f03-4873-86f9-880d7d00e957/0e3834c9efbd4b1193dcc6f5415a2eff.png",
    bgGradient: "from-blue-500 via-purple-500 to-indigo-600"
  },
  {
    id: 2,
    title: "Practice Unlimited Quizzes",
    subtitle: "Covers boards, exams, courses",
    description: "Test your knowledge with comprehensive quizzes designed for various educational levels and subjects.",
    illustration: "https://public.youware.com/users-website-assets/prod/a9adc6a9-2f03-4873-86f9-880d7d00e957/d42e531386de401180a96c305b4a2b46.jpg",
    bgGradient: "from-purple-500 via-pink-500 to-red-500"
  },
  {
    id: 3,
    title: "Challenge Friends & Win Badges",
    subtitle: "Gamified learning with streaks & coins",
    description: "Compete with friends, earn rewards, and maintain learning streaks to make education fun and engaging.",
    illustration: "https://public.youware.com/users-website-assets/prod/a9adc6a9-2f03-4873-86f9-880d7d00e957/2037d45bf553420ca63b19a784fe37ed.jpg",
    bgGradient: "from-orange-500 via-red-500 to-pink-600"
  },
  {
    id: 4,
    title: "Track Your Progress",
    subtitle: "Analytics, reports, certificates",
    description: "Monitor your learning journey with detailed analytics, progress reports, and earn certificates for achievements.",
    illustration: "https://public.youware.com/users-website-assets/prod/a9adc6a9-2f03-4873-86f9-880d7d00e957/4a464c44067246d89ada532e4315cd54.jpg",
    bgGradient: "from-teal-500 via-green-500 to-blue-600"
  }
];

interface OnboardingTutorialProps {
  onComplete?: () => void;
}

const OnboardingTutorial: React.FC<OnboardingTutorialProps> = ({ onComplete }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const skipOnboarding = () => {
    if (onComplete) {
      onComplete();
    } else {
      navigate('/');
    }
  };

  const getStarted = () => {
    if (onComplete) {
      onComplete();
    } else {
      navigate('/');
    }
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  return (
    <div className="min-h-screen overflow-hidden relative">
      <AnimatePresence mode="wait" custom={currentSlide}>
        <motion.div
          key={currentSlide}
          custom={currentSlide}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
          }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);

            if (swipe < -swipeConfidenceThreshold) {
              nextSlide();
            } else if (swipe > swipeConfidenceThreshold) {
              prevSlide();
            }
          }}
          className={`absolute inset-0 bg-gradient-to-br ${slides[currentSlide].bgGradient} flex flex-col items-center justify-center px-6 py-8`}
        >
          {/* Skip Button */}
          <div className="absolute top-8 right-6 z-10">
            <button
              onClick={skipOnboarding}
              className="text-white/80 hover:text-white transition-colors duration-200 text-sm font-medium"
            >
              Skip
            </button>
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto text-center">
            {/* Illustration */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="mb-8"
            >
              <img
                src={slides[currentSlide].illustration}
                alt={slides[currentSlide].title}
                className="w-64 h-48 object-contain rounded-lg shadow-lg"
              />
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight"
            >
              {slides[currentSlide].title}
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="text-white/90 text-lg font-medium mb-4"
            >
              {slides[currentSlide].subtitle}
            </motion.p>

            {/* Description */}
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="text-white/80 text-base leading-relaxed max-w-sm"
            >
              {slides[currentSlide].description}
            </motion.p>
          </div>

          {/* Bottom Navigation */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="w-full max-w-md mx-auto"
          >
            {/* Progress Dots */}
            <div className="flex justify-center items-center mb-8 space-x-2">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentSlide
                      ? 'bg-white scale-125'
                      : 'bg-white/50 hover:bg-white/70'
                  }`}
                />
              ))}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between items-center">
              {/* Previous Button */}
              <button
                onClick={prevSlide}
                disabled={currentSlide === 0}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                  currentSlide === 0
                    ? 'text-white/50 cursor-not-allowed'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <ChevronLeft size={20} />
                <span className="font-medium">Back</span>
              </button>

              {/* Next/Get Started Button */}
              {currentSlide === slides.length - 1 ? (
                <Button
                  onClick={getStarted}
                  className="bg-gradient-to-r from-teal-400 to-cyan-500 hover:from-teal-500 hover:to-cyan-600 text-white font-semibold px-8 py-3 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-200"
                >
                  Get Started
                </Button>
              ) : (
                <button
                  onClick={nextSlide}
                  className="flex items-center space-x-2 px-6 py-3 bg-white/20 hover:bg-white/30 text-white rounded-lg font-medium transition-all duration-200 hover:scale-105"
                >
                  <span>Next</span>
                  <ChevronRight size={20} />
                </button>
              )}
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default OnboardingTutorial;