import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/Layout';
import Card from '../components/Card';
import ResponsiveGrid from '../components/ResponsiveGrid';
import Button from '../components/Button';
import Modal from '../components/Modal';

interface Course {
  id: string;
  name: string;
  description: string;
  subjects: Subject[];
  isVisible: boolean;
  createdAt: string;
}

interface Subject {
  id: string;
  name: string;
  chapters: Chapter[];
  isVisible: boolean;
}

interface Chapter {
  id: string;
  name: string;
  sets: QuizSet[];
  isVisible: boolean;
}

interface QuizSet {
  id: string;
  name: string;
  questions: Question[];
  isVisible: boolean;
}

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'courses' | 'subjects' | 'chapters' | 'sets' | 'questions'>('courses');
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [selectedCourse, setSelectedCourse] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [selectedChapter, setSelectedChapter] = useState<string>('');

  // Mock data - In real app, this would come from backend
  const [courses, setCourses] = useState<Course[]>([
    {
      id: '1',
      name: 'Computer Science',
      description: 'Programming and software development topics',
      subjects: [],
      isVisible: true,
      createdAt: '2024-01-15'
    },
    {
      id: '2', 
      name: 'Mathematics',
      description: 'Mathematical concepts and problem solving',
      subjects: [],
      isVisible: true,
      createdAt: '2024-01-10'
    }
  ]);

  const tabs = [
    { id: 'courses', label: 'Courses', icon: '📚', count: courses.length },
    { id: 'subjects', label: 'Subjects', icon: '📖', count: 12 },
    { id: 'chapters', label: 'Chapters', icon: '📝', count: 45 },
    { id: 'sets', label: 'Quiz Sets', icon: '❓', count: 128 },
    { id: 'questions', label: 'Questions', icon: '💭', count: 1250 }
  ];

  const handleAdd = () => {
    setEditingItem(null);
    setShowModal(true);
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    setShowModal(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this item?')) {
      if (activeTab === 'courses') {
        setCourses(courses.filter(c => c.id !== id));
      }
      // Add similar logic for other tabs
    }
  };

  const toggleVisibility = (id: string) => {
    if (activeTab === 'courses') {
      setCourses(courses.map(c => 
        c.id === id ? { ...c, isVisible: !c.isVisible } : c
      ));
    }
    // Add similar logic for other tabs
  };

  const renderCourses = () => (
    <ResponsiveGrid cols={{ default: 1, md: 2, lg: 3 }} gap={6}>
      {courses.map((course) => (
        <Card key={course.id} variant="elevated" className="relative">
          <div className="absolute top-4 right-4 flex gap-2">
            <button
              onClick={() => toggleVisibility(course.id)}
              className={`p-2 rounded-lg ${course.isVisible ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}
            >
              {course.isVisible ? '👁️' : '🚫'}
            </button>
            <button
              onClick={() => handleEdit(course)}
              className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200"
            >
              ✏️
            </button>
            <button
              onClick={() => handleDelete(course.id)}
              className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
            >
              🗑️
            </button>
          </div>
          
          <div className="pr-20">
            <h3 className="text-xl font-bold text-gray-900 mb-2">{course.name}</h3>
            <p className="text-gray-600 mb-4">{course.description}</p>
            <div className="flex justify-between text-sm text-gray-500">
              <span>Created: {course.createdAt}</span>
              <span className={`px-2 py-1 rounded-full text-xs ${course.isVisible ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                {course.isVisible ? 'Visible' : 'Hidden'}
              </span>
            </div>
          </div>
        </Card>
      ))}
    </ResponsiveGrid>
  );

  const renderPlaceholder = (type: string) => (
    <Card variant="outlined" className="text-center py-12">
      <div className="text-6xl mb-4">📋</div>
      <h3 className="text-xl font-semibold text-gray-700 mb-2">No {type} Yet</h3>
      <p className="text-gray-500 mb-6">Start by creating your first {type.toLowerCase()}</p>
      <Button onClick={handleAdd} variant="primary">
        Add {type.slice(0, -1)}
      </Button>
    </Card>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'courses':
        return courses.length > 0 ? renderCourses() : renderPlaceholder('Courses');
      case 'subjects':
        return renderPlaceholder('Subjects');
      case 'chapters':
        return renderPlaceholder('Chapters');
      case 'sets':
        return renderPlaceholder('Quiz Sets');
      case 'questions':
        return renderPlaceholder('Questions');
      default:
        return null;
    }
  };

  return (
    <Layout showHeader={false} showFooter={false}>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              </div>
              <div className="flex items-center gap-4">
                <Button onClick={handleAdd} variant="primary" icon="➕">
                  Add New
                </Button>
                <Button onClick={() => window.location.href = '/'} variant="outline">
                  Exit Admin
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Statistics Cards */}
          <ResponsiveGrid cols={{ default: 2, md: 5 }} gap={4} className="mb-8">
            {tabs.map((tab) => (
              <Card
                key={tab.id}
                variant={activeTab === tab.id ? 'elevated' : 'default'}
                className={`cursor-pointer transition-all duration-200 ${
                  activeTab === tab.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setActiveTab(tab.id as any)}
              >
                <div className="text-center">
                  <div className="text-3xl mb-2">{tab.icon}</div>
                  <div className="text-2xl font-bold text-gray-900">{tab.count}</div>
                  <div className="text-sm text-gray-600">{tab.label}</div>
                </div>
              </Card>
            ))}
          </ResponsiveGrid>

          {/* Content Area */}
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderContent()}
          </motion.div>
        </div>

        {/* Add/Edit Modal */}
        <Modal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          title={`${editingItem ? 'Edit' : 'Add'} ${activeTab.slice(0, -1)}`}
          size="large"
        >
          <form className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Name
              </label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={`Enter ${activeTab.slice(0, -1)} name`}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={`Enter ${activeTab.slice(0, -1)} description`}
              />
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="isVisible"
                className="mr-2"
                defaultChecked={true}
              />
              <label htmlFor="isVisible" className="text-sm font-medium text-gray-700">
                Visible to users
              </label>
            </div>

            <div className="flex gap-4 pt-4">
              <Button type="submit" variant="primary" fullWidth>
                {editingItem ? 'Update' : 'Create'} {activeTab.slice(0, -1)}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                fullWidth
                onClick={() => setShowModal(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Modal>
      </div>
    </Layout>
  );
};

export default AdminDashboard;