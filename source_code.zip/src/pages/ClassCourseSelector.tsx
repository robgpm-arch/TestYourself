import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ClassOption {
  id: string;
  number: number;
  name: string;
  subjects: string[];
  color: string;
  icon: string;
}

interface CourseOption {
  id: string;
  name: string;
  type: string;
  duration: string;
  icon: string;
  color: string;
  examType: string;
}

const classOptions: ClassOption[] = [
  {
    id: 'class-6',
    number: 6,
    name: 'Class 6',
    subjects: ['Math', 'Science', 'English'],
    color: 'from-pink-400 to-rose-500',
    icon: '📚'
  },
  {
    id: 'class-7',
    number: 7,
    name: 'Class 7',
    subjects: ['Math', 'Science', 'English'],
    color: 'from-purple-400 to-violet-500',
    icon: '📖'
  },
  {
    id: 'class-8',
    number: 8,
    name: 'Class 8',
    subjects: ['Math', 'Science', 'English'],
    color: 'from-blue-400 to-cyan-500',
    icon: '📝'
  },
  {
    id: 'class-9',
    number: 9,
    name: 'Class 9',
    subjects: ['Math', 'Physics', 'Chemistry', 'Biology'],
    color: 'from-green-400 to-emerald-500',
    icon: '🔬'
  },
  {
    id: 'class-10',
    number: 10,
    name: 'Class 10',
    subjects: ['Math', 'Physics', 'Chemistry', 'Biology'],
    color: 'from-yellow-400 to-orange-500',
    icon: '🎯'
  },
  {
    id: 'class-11',
    number: 11,
    name: 'Class 11',
    subjects: ['PCM/PCB', 'Commerce', 'Arts'],
    color: 'from-red-400 to-pink-500',
    icon: '🎓'
  },
  {
    id: 'class-12',
    number: 12,
    name: 'Class 12',
    subjects: ['PCM/PCB', 'Commerce', 'Arts'],
    color: 'from-indigo-400 to-purple-500',
    icon: '🏆'
  }
];

const courseOptions: { [key: string]: CourseOption[] } = {
  jee: [
    {
      id: 'jee-foundation',
      name: 'JEE Foundation',
      type: 'Foundation Course',
      duration: '2 Years • Classes 11-12',
      icon: '🏗️',
      color: 'from-blue-500 to-indigo-600',
      examType: 'jee'
    },
    {
      id: 'jee-crash',
      name: 'JEE Crash Course',
      type: 'Intensive Prep',
      duration: '6 Months • 2025 Target',
      icon: '⚡',
      color: 'from-orange-500 to-red-600',
      examType: 'jee'
    },
    {
      id: 'jee-full',
      name: 'JEE Full Syllabus',
      type: 'Complete Coverage',
      duration: '1 Year • Main + Advanced',
      icon: '📋',
      color: 'from-green-500 to-teal-600',
      examType: 'jee'
    },
    {
      id: 'jee-test',
      name: 'JEE Test Series',
      type: 'Practice & Mock Tests',
      duration: '6 Months • 100+ Tests',
      icon: '🎯',
      color: 'from-purple-500 to-indigo-600',
      examType: 'jee'
    }
  ],
  neet: [
    {
      id: 'neet-foundation',
      name: 'NEET Foundation',
      type: 'Foundation Course',
      duration: '2 Years • Classes 11-12',
      icon: '🏥',
      color: 'from-green-500 to-emerald-600',
      examType: 'neet'
    },
    {
      id: 'neet-crash',
      name: 'NEET Crash Course',
      type: 'Intensive Prep',
      duration: '4 Months • 2025 Target',
      icon: '💊',
      color: 'from-red-500 to-pink-600',
      examType: 'neet'
    },
    {
      id: 'neet-full',
      name: 'NEET Full Syllabus',
      type: 'Complete Coverage',
      duration: '1 Year • Physics, Chemistry, Biology',
      icon: '🔬',
      color: 'from-blue-500 to-cyan-600',
      examType: 'neet'
    },
    {
      id: 'neet-test',
      name: 'NEET Test Series',
      type: 'Practice & Mock Tests',
      duration: '6 Months • Weekly Tests',
      icon: '📊',
      color: 'from-purple-500 to-violet-600',
      examType: 'neet'
    }
  ],
  upsc: [
    {
      id: 'upsc-prelims',
      name: 'UPSC Prelims',
      type: 'Preliminary Exam',
      duration: '8 Months • General Studies',
      icon: '📚',
      color: 'from-indigo-500 to-purple-600',
      examType: 'upsc'
    },
    {
      id: 'upsc-mains',
      name: 'UPSC Mains',
      type: 'Main Examination',
      duration: '1 Year • Essay + Optional',
      icon: '✍️',
      color: 'from-blue-500 to-indigo-600',
      examType: 'upsc'
    },
    {
      id: 'upsc-complete',
      name: 'UPSC Complete',
      type: 'Prelims + Mains + Interview',
      duration: '18 Months • Full Preparation',
      icon: '🏛️',
      color: 'from-green-500 to-blue-600',
      examType: 'upsc'
    }
  ],
  ssc: [
    {
      id: 'ssc-cgl',
      name: 'SSC CGL',
      type: 'Combined Graduate Level',
      duration: '6 Months • Tier 1 + Tier 2',
      icon: '📋',
      color: 'from-orange-500 to-red-600',
      examType: 'ssc'
    },
    {
      id: 'ssc-chsl',
      name: 'SSC CHSL',
      type: 'Combined Higher Secondary',
      duration: '4 Months • Tier 1 + Tier 2',
      icon: '📝',
      color: 'from-blue-500 to-cyan-600',
      examType: 'ssc'
    }
  ],
  banking: [
    {
      id: 'banking-po',
      name: 'Banking PO',
      type: 'Probationary Officer',
      duration: '8 Months • SBI + IBPS',
      icon: '🏦',
      color: 'from-green-500 to-teal-600',
      examType: 'banking'
    },
    {
      id: 'banking-clerk',
      name: 'Banking Clerk',
      type: 'Clerical Cadre',
      duration: '6 Months • All Banks',
      icon: '💼',
      color: 'from-blue-500 to-indigo-600',
      examType: 'banking'
    }
  ],
  // Default fallback for other exams
  default: [
    {
      id: 'general-prep',
      name: 'Complete Preparation',
      type: 'Full Syllabus Coverage',
      duration: '8 Months • 2025 Target',
      icon: '📚',
      color: 'from-gray-500 to-slate-600',
      examType: 'general'
    },
    {
      id: 'test-series',
      name: 'Test Series',
      type: 'Practice & Mock Tests',
      duration: '4 Months • Regular Tests',
      icon: '🎯',
      color: 'from-purple-500 to-indigo-600',
      examType: 'general'
    }
  ]
};

// Board categories that show class selection
const boardCategories = ['cbse', 'icse', 'isc', 'iit-foundation', 'ts-board', 'ap-board', 'tn-board', 'mh-board'];

interface ClassCourseSelectorProps {
  selectedBoardExam: string;
  onSelection: (selection: string) => void;
}

const ClassCourseSelector: React.FC<ClassCourseSelectorProps> = ({ selectedBoardExam, onSelection }) => {
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [isConfirming, setIsConfirming] = useState(false);
  
  const isBoard = boardCategories.includes(selectedBoardExam);
  const currentCourses = courseOptions[selectedBoardExam] || courseOptions.default;

  const handleOptionSelect = (optionId: string) => {
    setSelectedOption(optionId);
    setIsConfirming(true);
    
    // Auto-hide confirmation after 2 seconds
    setTimeout(() => {
      setIsConfirming(false);
    }, 2000);
  };

  const handleContinue = () => {
    if (selectedOption) {
      onSelection(selectedOption);
    }
  };

  const getSelectedOptionName = () => {
    if (isBoard) {
      const classOption = classOptions.find(c => c.id === selectedOption);
      return classOption?.name;
    } else {
      const courseOption = currentCourses.find(c => c.id === selectedOption);
      return courseOption?.name;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-400 via-teal-300 to-white relative overflow-hidden">
      {/* Decorative background icons */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-20 left-20 text-8xl transform rotate-12">🎓</div>
        <div className="absolute top-40 right-32 text-6xl transform -rotate-6">⚛️</div>
        <div className="absolute bottom-32 left-40 text-7xl transform rotate-45">✏️</div>
        <div className="absolute bottom-20 right-20 text-5xl transform -rotate-12">📐</div>
        <div className="absolute top-1/2 left-1/4 text-4xl transform rotate-90">🧮</div>
        <div className="absolute top-1/3 right-1/3 text-6xl transform -rotate-30">📊</div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Select Your {isBoard ? 'Class' : 'Course'}
          </h1>
          <p className="text-teal-100 text-lg md:text-xl font-medium">
            This will help us personalize your quizzes
          </p>
        </motion.div>

        {/* Dynamic Content Based on Selection */}
        <AnimatePresence mode="wait">
          {isBoard ? (
            // Case A: Board Students - Class Grid
            <motion.div
              key="classes"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.6 }}
              className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 w-full max-w-4xl mb-12"
            >
              {classOptions.map((classOption, index) => (
                <motion.div
                  key={classOption.id}
                  initial={{ opacity: 0, y: 20, rotateY: 180 }}
                  animate={{ opacity: 1, y: 0, rotateY: 0 }}
                  transition={{ 
                    duration: 0.6, 
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ scale: 1.05, rotateY: 5 }}
                  whileTap={{ 
                    scale: 0.95,
                    rotateY: selectedOption === classOption.id ? 360 : 180,
                    transition: { duration: 0.6 }
                  }}
                  onClick={() => handleOptionSelect(classOption.id)}
                  className={`
                    relative cursor-pointer rounded-3xl p-8 aspect-square
                    bg-gradient-to-br ${classOption.color} text-white
                    shadow-lg hover:shadow-2xl transition-all duration-300
                    ${selectedOption === classOption.id 
                      ? 'ring-4 ring-white ring-opacity-50 shadow-2xl scale-105' 
                      : ''
                    }
                  `}
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  <div className="text-center h-full flex flex-col justify-center">
                    {/* Class Icon */}
                    <div className="text-4xl md:text-5xl mb-4">
                      {classOption.icon}
                    </div>

                    {/* Class Number */}
                    <div className="text-4xl md:text-5xl font-bold mb-2">
                      {classOption.number}
                    </div>

                    {/* Class Name */}
                    <div className="text-lg font-semibold mb-3">
                      {classOption.name}
                    </div>

                    {/* Subjects */}
                    <div className="text-sm opacity-90 leading-relaxed">
                      {classOption.subjects.join(' • ')}
                    </div>

                    {/* Selection indicator */}
                    {selectedOption === classOption.id && (
                      <motion.div
                        initial={{ scale: 0, rotate: -180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        className="absolute -top-3 -right-3 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg"
                      >
                        <svg className="w-6 h-6 text-teal-500" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            // Case B: Competitive Exams - Course Cards
            <motion.div
              key="courses"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.6 }}
              className="w-full max-w-4xl space-y-4 mb-12"
            >
              {currentCourses.map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ 
                    duration: 0.5, 
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOptionSelect(course.id)}
                  className={`
                    relative cursor-pointer rounded-2xl p-6 bg-white/95 backdrop-blur-sm
                    shadow-lg hover:shadow-2xl transition-all duration-300
                    ${selectedOption === course.id 
                      ? 'ring-4 ring-teal-300 shadow-2xl bg-white scale-102' 
                      : 'hover:bg-white'
                    }
                  `}
                >
                  <div className="flex items-center space-x-6">
                    {/* Course Icon */}
                    <div className={`flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br ${course.color} flex items-center justify-center text-2xl text-white shadow-lg`}>
                      {course.icon}
                    </div>

                    {/* Course Details */}
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-800 mb-1">
                        {course.name}
                      </h3>
                      <p className="text-lg text-gray-600 font-medium mb-2">
                        {course.type}
                      </p>
                      <p className="text-sm text-gray-500 font-medium">
                        {course.duration}
                      </p>
                    </div>

                    {/* Selection indicator */}
                    {selectedOption === course.id && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="flex-shrink-0 w-10 h-10 bg-teal-500 rounded-full flex items-center justify-center"
                      >
                        <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </motion.div>
                    )}
                  </div>

                  {/* Glowing border effect for selected */}
                  {selectedOption === course.id && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="absolute inset-0 rounded-2xl bg-gradient-to-r from-teal-400 to-cyan-400 opacity-10 blur-sm"
                    />
                  )}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Confirmation Message */}
        <AnimatePresence>
          {isConfirming && selectedOption && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className="mb-8 px-6 py-3 bg-white/90 backdrop-blur-sm rounded-full shadow-lg"
            >
              <p className="text-teal-700 font-semibold text-center">
                {getSelectedOptionName()} selected!
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Continue Button */}
        <motion.button
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: selectedOption ? 1 : 0.5, y: 0 }}
          whileHover={selectedOption ? { scale: 1.05 } : {}}
          whileTap={selectedOption ? { scale: 0.98 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          onClick={handleContinue}
          disabled={!selectedOption}
          className={`
            px-12 py-4 rounded-full font-bold text-lg text-white
            bg-gradient-to-r from-teal-500 to-cyan-500
            shadow-lg hover:shadow-xl
            transition-all duration-300
            ${selectedOption 
              ? 'cursor-pointer' 
              : 'cursor-not-allowed opacity-50'
            }
          `}
        >
          Continue
        </motion.button>

        {/* Progress indicator */}
        <div className="flex space-x-2 mt-8">
          {[1, 2, 3, 4, 5, 6].map((step, index) => (
            <div
              key={step}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                index === 5 ? 'bg-teal-500' : 'bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ClassCourseSelector;