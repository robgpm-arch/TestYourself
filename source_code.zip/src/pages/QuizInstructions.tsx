import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import Button from '../components/Button';

interface InstructionCard {
  id: string;
  icon: string;
  title: string;
  description: string;
}

const QuizInstructions: React.FC = () => {
  const navigate = useNavigate();
  const [isAutoRunEnabled, setIsAutoRunEnabled] = useState(false);

  // Instruction cards data
  const instructions: InstructionCard[] = [
    {
      id: 'time',
      icon: '⏱️',
      title: 'Time Limit',
      description: "You'll have 30 minutes to complete this quiz."
    },
    {
      id: 'questions',
      icon: '❓',
      title: 'Questions',
      description: '20 multiple choice questions.'
    },
    {
      id: 'scoring',
      icon: '🏆',
      title: 'Scoring',
      description: '+1 for correct, 0 for wrong, 0 for skipped.'
    },
    {
      id: 'navigation',
      icon: '🔄',
      title: 'Navigation',
      description: 'You can skip and return before submitting.'
    },
    {
      id: 'integrity',
      icon: '📶',
      title: 'Integrity',
      description: 'Do not switch apps during exam mode.'
    }
  ];

  const handleBack = () => {
    navigate(-1); // Go back to previous page
  };

  const handleStartQuiz = () => {
    // In real app, this would navigate to quiz page
    console.log('Starting quiz...');
    navigate('/quiz'); // Navigate to quiz page
  };

  const handleAutoRunQuiz = () => {
    // In real app, this would start automated quiz
    console.log('Starting auto-run quiz...');
    setIsAutoRunEnabled(true);
    // Simulate auto-run start delay
    setTimeout(() => {
      navigate('/quiz/auto-run');
    }, 2000);
  };

  // Animation variants
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (index: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.15,
        duration: 0.6,
        type: "spring",
        stiffness: 100,
        damping: 12
      }
    })
  };

  const buttonPulse = {
    scale: [1, 1.05, 1],
    transition: {
      duration: 2,
      repeat: Infinity,
      ease: "easeInOut"
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-200 to-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 text-6xl">📄</div>
        <div className="absolute top-20 right-20 text-4xl">⏱️</div>
        <div className="absolute bottom-20 left-20 text-5xl">📄</div>
        <div className="absolute bottom-10 right-10 text-3xl">⏱️</div>
        <div className="absolute top-1/2 left-1/4 text-4xl">📄</div>
        <div className="absolute top-1/3 right-1/4 text-5xl">⏱️</div>
        <div className="absolute top-2/3 left-1/2 text-3xl">📄</div>
        <div className="absolute top-1/4 right-1/2 text-4xl">⏱️</div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center py-8 px-4"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Quiz Instructions</h1>
          <p className="text-gray-600 text-lg">Please read before you begin</p>
        </motion.div>

        {/* Instruction Cards */}
        <div className="flex-1 px-4 pb-8">
          <div className="max-w-4xl mx-auto">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {instructions.map((instruction, index) => (
                <motion.div
                  key={instruction.id}
                  custom={index}
                  initial="hidden"
                  animate="visible"
                  variants={cardVariants}
                  className="h-full"
                >
                  <Card
                    variant="elevated"
                    className="h-full flex flex-col justify-center text-center p-6 hover:shadow-xl transition-shadow duration-300"
                    hover={true}
                  >
                    <div className="mb-4">
                      <div className="text-4xl mb-3">{instruction.icon}</div>
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">
                        {instruction.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        {instruction.description}
                      </p>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Additional Information Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              className="mt-8"
            >
              <Card variant="gradient" className="text-center p-6">
                <div className="flex items-center justify-center mb-4">
                  <span className="text-3xl mr-3">💡</span>
                  <h3 className="text-lg font-semibold text-gray-800">Pro Tip</h3>
                </div>
                <p className="text-gray-700">
                  Read each question carefully and take your time. You can always review your answers before final submission.
                </p>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Footer Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.6 }}
          className="bg-white/80 backdrop-blur-sm border-t border-gray-200 p-6"
        >
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              {/* Back Button */}
              <Button
                onClick={handleBack}
                variant="outline"
                size="large"
                className="border-gray-300 text-gray-700 hover:bg-gray-50 min-w-[120px]"
              >
                ← Back
              </Button>

              {/* Auto Run Quiz Button */}
              <Button
                onClick={handleAutoRunQuiz}
                variant="secondary"
                size="large"
                disabled={isAutoRunEnabled}
                className="bg-purple-100 text-purple-700 border-purple-200 hover:bg-purple-200 min-w-[160px] relative"
              >
                {isAutoRunEnabled ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-2 border-purple-600 border-t-transparent rounded-full mr-2" />
                    Starting...
                  </>
                ) : (
                  <>
                    🤖 Auto Run Quiz
                  </>
                )}
              </Button>

              {/* Start Quiz Button - Main CTA */}
              <motion.div animate={buttonPulse}>
                <Button
                  onClick={handleStartQuiz}
                  variant="primary"
                  size="large"
                  className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-lg min-w-[180px] relative overflow-hidden"
                >
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-500 opacity-0"
                    whileHover={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                  <span className="relative z-10 flex items-center justify-center">
                    I'm Ready - Start Quiz 🚀
                  </span>
                </Button>
              </motion.div>
            </div>

            {/* Additional Help Text */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2, duration: 0.6 }}
              className="text-center mt-6"
            >
              <p className="text-sm text-gray-500">
                Need help? Contact support or review our{' '}
                <button className="text-blue-600 hover:text-blue-800 underline">
                  quiz guidelines
                </button>
              </p>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Auto Run Quiz Overlay */}
      {isAutoRunEnabled && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl p-8 max-w-md mx-4 text-center"
          >
            <div className="text-4xl mb-4">🤖</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              Auto Run Quiz Initializing...
            </h3>
            <p className="text-gray-600 mb-4">
              The quiz will run automatically and help you learn through guided practice.
            </p>
            <div className="flex justify-center">
              <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full" />
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default QuizInstructions;