import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import SplashScreen from "./pages/SplashScreen";
import OnboardingTutorial from "./pages/OnboardingTutorial";
import MediumPicker from "./pages/MediumPicker";
import BoardExamSelector from "./pages/BoardExamSelector";
import ClassCourseSelector from "./pages/ClassCourseSelector";
import SubjectSelector from "./pages/SubjectSelector";
import LoginSignup from "./pages/LoginSignup";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import AdminDashboard from "./pages/AdminDashboard";
import SyllabusBrowser from "./pages/SyllabusBrowser";
import QuizInstructions from "./pages/QuizInstructions";
import ThemePicker from "./pages/ThemePicker";
import QuizPlayer from "./pages/QuizPlayer";
import QuizPlayerNumerical from "./pages/QuizPlayerNumerical";
import QuizPlayerComprehension from "./pages/QuizPlayerComprehension";
import ExamMode from "./pages/ExamMode";
import ResultsCelebration from "./pages/ResultsCelebration";
import DetailedAnalytics from "./pages/DetailedAnalytics";
import Leaderboards from "./pages/Leaderboards";
import ChapterSets from "./pages/ChapterSets";

function App() {
  // Check for demo authentication from localStorage
  const [isAuthenticated, setIsAuthenticated] = useState(
    localStorage.getItem('demo_authenticated') === 'true'
  );
  const [showSplash, setShowSplash] = useState(
    localStorage.getItem('demo_authenticated') !== 'true' && localStorage.getItem('test_show_login') !== 'true'
  );
  const [showOnboarding, setShowOnboarding] = useState(
    localStorage.getItem('onboarding_completed') !== 'true' && localStorage.getItem('demo_authenticated') !== 'true'
  );
  const [showMediumPicker, setShowMediumPicker] = useState(
    localStorage.getItem('medium_selected') !== 'true' && localStorage.getItem('demo_authenticated') !== 'true'
  );
  const [showBoardExamSelector, setShowBoardExamSelector] = useState(
    localStorage.getItem('board_exam_selected') !== 'true' && localStorage.getItem('demo_authenticated') !== 'true'
  );
  const [showClassCourseSelector, setShowClassCourseSelector] = useState(
    localStorage.getItem('class_course_selected') !== 'true' && localStorage.getItem('demo_authenticated') !== 'true'
  );
  const [showSubjectSelector, setShowSubjectSelector] = useState(
    localStorage.getItem('subject_selected') !== 'true' && localStorage.getItem('demo_authenticated') !== 'true'
  );
  const [showLogin, setShowLogin] = useState(
    localStorage.getItem('test_show_login') === 'true'
  );
  const [selectedMedium, setSelectedMedium] = useState('');
  const [selectedBoardExam, setSelectedBoardExam] = useState('');
  const [selectedClassCourse, setSelectedClassCourse] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);

  const handleLogin = () => {
    localStorage.removeItem('test_show_login');
    localStorage.setItem('demo_authenticated', 'true');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleGetStarted = () => {
    setShowSplash(false);
    setShowOnboarding(true);
  };

  const handleSignIn = () => {
    setShowSplash(false);
    setShowLogin(true);
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    setShowMediumPicker(true);
  };

  const handleMediumSelect = (medium: string) => {
    setSelectedMedium(medium);
    setShowMediumPicker(false);
    setShowBoardExamSelector(true);
  };

  const handleBoardExamSelect = (selection: string) => {
    setSelectedBoardExam(selection);
    setShowBoardExamSelector(false);
    setShowClassCourseSelector(true);
  };

  const handleClassCourseSelect = (selection: string) => {
    setSelectedClassCourse(selection);
    setShowClassCourseSelector(false);
    setShowSubjectSelector(true);
  };

  const handleSubjectSelect = (subject: string) => {
    setSelectedSubject(subject);
    setShowSubjectSelector(false);
  };

  const handleAdminLogin = () => {
    setIsAdmin(true);
    setShowSplash(false);
  };

  return (
    <Router>
      {showSplash && (
        <SplashScreen onGetStarted={handleGetStarted} onSignIn={handleSignIn} />
      )}

      {showLogin && (
        <LoginSignup 
          onLogin={() => {
            handleLogin();
            setShowLogin(false);
          }} 
          onSkip={() => setShowLogin(false)}
        />
      )}

      {showOnboarding && (
        <OnboardingTutorial onComplete={handleOnboardingComplete} />
      )}

      {showMediumPicker && (
        <MediumPicker onMediumSelect={handleMediumSelect} />
      )}

      {showBoardExamSelector && (
        <BoardExamSelector onSelection={handleBoardExamSelect} />
      )}

      {showClassCourseSelector && (
        <ClassCourseSelector 
          selectedBoardExam={selectedBoardExam}
          onSelection={handleClassCourseSelect} 
        />
      )}

      {showSubjectSelector && (
        <SubjectSelector onSubjectSelect={handleSubjectSelect} />
      )}

      {isAdmin && (
        <AdminDashboard />
      )}



      {isAuthenticated && !showSplash && !showOnboarding && !showMediumPicker && !showBoardExamSelector && !showClassCourseSelector && !showSubjectSelector && !isAdmin && (
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/syllabus" element={<SyllabusBrowser />} />
          <Route path="/quiz-instructions" element={<QuizInstructions />} />
          <Route path="/quiz-player" element={<QuizPlayer />} />
          <Route path="/quiz-player-numerical" element={<QuizPlayerNumerical />} />
          <Route path="/quiz-player-comprehension" element={<QuizPlayerComprehension />} />
          <Route path="/exam-mode" element={<ExamMode />} />
          <Route path="/results-celebration" element={<ResultsCelebration />} />
          <Route path="/detailed-analytics" element={<DetailedAnalytics />} />
          <Route path="/leaderboards" element={<Leaderboards />} />
          <Route path="/chapter-sets" element={<ChapterSets />} />
          <Route path="/theme-picker" element={<ThemePicker />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      )}
    </Router>
  );
}

export default App;
