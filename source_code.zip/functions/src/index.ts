import { onCall, onRequest, HttpsError } from 'firebase-functions/v2/https';
import { onDocumentCreated, onDocumentUpdated } from 'firebase-functions/v2/firestore';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import express from 'express';
import cors from 'cors';

// Initialize Firebase Admin
initializeApp();
const db = getFirestore();
const auth = getAuth();

// Express app for API routes
const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

/**
 * USER MANAGEMENT FUNCTIONS
 */

// Create user profile after authentication
export const createUserProfile = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { uid } = request.auth;
  const { displayName, email } = request.data;

  try {
    const userProfile = {
      uid,
      email,
      displayName,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: {
        firstName: displayName?.split(' ')[0] || '',
        lastName: displayName?.split(' ')[1] || '',
        achievements: [],
        badges: []
      },
      stats: {
        totalQuizzesCompleted: 0,
        totalQuestionsAnswered: 0,
        correctAnswers: 0,
        accuracy: 0,
        totalTimeSpent: 0,
        streakCurrent: 0,
        streakBest: 0,
        level: 1,
        experiencePoints: 0,
        favoriteSubjects: [],
        averageScore: 0
      }
    };

    await db.collection('users').doc(uid).set(userProfile);
    return { success: true, data: userProfile };
  } catch (error) {
    console.error('Error creating user profile:', error);
    throw new HttpsError('internal', 'Failed to create user profile');
  }
});

/**
 * QUIZ MANAGEMENT FUNCTIONS
 */

// Calculate quiz results and update user stats
export const calculateQuizResults = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { uid } = request.auth;
  const { quizId, answers, timeSpent } = request.data;

  try {
    // Get quiz data
    const quizDoc = await db.collection('quizzes').doc(quizId).get();
    if (!quizDoc.exists) {
      throw new HttpsError('not-found', 'Quiz not found');
    }

    const quiz = quizDoc.data()!;
    const questions = quiz.questions;

    // Calculate results
    let correctAnswers = 0;
    let totalScore = 0;
    const maxScore = questions.reduce((sum: number, q: any) => sum + q.points, 0);

    const processedAnswers = answers.map((answer: any, index: number) => {
      const question = questions[index];
      const isCorrect = answer.answer === question.correctAnswer;
      
      if (isCorrect) {
        correctAnswers++;
        totalScore += question.points;
      }

      return {
        questionId: question.id,
        answer: answer.answer,
        isCorrect,
        timeSpent: answer.timeSpent || 0,
        hintsUsed: answer.hintsUsed || 0
      };
    });

    const percentage = (totalScore / maxScore) * 100;
    const passed = percentage >= quiz.passingScore;

    // Create quiz attempt record
    const attemptData = {
      quizId,
      userId: uid,
      startTime: new Date(Date.now() - timeSpent * 1000),
      endTime: new Date(),
      duration: timeSpent,
      score: totalScore,
      percentage,
      passed,
      answers: processedAnswers,
      status: 'completed'
    };

    const attemptRef = await db.collection('quiz_attempts').add(attemptData);

    // Update user stats
    await updateUserStats(uid, {
      totalQuestions: questions.length,
      correctAnswers,
      timeSpent,
      score: totalScore,
      subject: quiz.subject
    });

    // Update quiz stats
    await updateQuizStats(quizId, totalScore, maxScore);

    return {
      success: true,
      data: {
        attemptId: attemptRef.id,
        score: totalScore,
        maxScore,
        percentage,
        passed,
        correctAnswers,
        totalQuestions: questions.length
      }
    };
  } catch (error) {
    console.error('Error calculating quiz results:', error);
    throw new HttpsError('internal', 'Failed to calculate quiz results');
  }
});

/**
 * LEADERBOARD FUNCTIONS
 */

// Update leaderboards when quiz is completed
export const updateLeaderboards = onDocumentCreated('quiz_attempts/{attemptId}', async (event) => {
  const attemptData = event.data?.data();
  if (!attemptData) return;

  const { userId, quizId, score, percentage } = attemptData;

  try {
    // Get user data
    const userDoc = await db.collection('users').doc(userId).get();
    const userData = userDoc.data();
    
    // Get quiz data for subject
    const quizDoc = await db.collection('quizzes').doc(quizId).get();
    const quizData = quizDoc.data();

    if (!userData || !quizData) return;

    const leaderboardEntry = {
      userId,
      username: userData.displayName || userData.email,
      avatar: userData.profile?.avatar || null,
      score: percentage,
      subject: quizData.subject,
      updatedAt: new Date()
    };

    // Update different leaderboard periods
    const periods = ['daily', 'weekly', 'monthly', 'all-time'];
    
    for (const period of periods) {
      const leaderboardRef = db.collection('leaderboards')
        .doc(`${period}_${quizData.subject}_${userId}`);
      
      await leaderboardRef.set({
        ...leaderboardEntry,
        period
      }, { merge: true });
    }

  } catch (error) {
    console.error('Error updating leaderboards:', error);
  }
});

/**
 * SUBSCRIPTION AND PAYMENT FUNCTIONS
 */

// Handle subscription creation
export const createSubscription = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { uid } = request.auth;
  const { priceId, paymentMethodId } = request.data;

  try {
    // This would integrate with your payment provider (Stripe, Razorpay, etc.)
    // For now, we'll create a basic subscription record
    
    const subscription = {
      userId: uid,
      type: priceId === 'price_pro' ? 'pro' : 'premium',
      status: 'active',
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      autoRenew: true,
      priceId,
      createdAt: new Date()
    };

    // Update user subscription
    await db.collection('users').doc(uid).update({
      subscription,
      updatedAt: new Date()
    });

    return { success: true, data: subscription };
  } catch (error) {
    console.error('Error creating subscription:', error);
    throw new HttpsError('internal', 'Failed to create subscription');
  }
});

/**
 * NOTIFICATION FUNCTIONS
 */

// Send welcome notification to new users
export const sendWelcomeNotification = onDocumentCreated('users/{userId}', async (event) => {
  const userData = event.data?.data();
  const userId = event.params.userId;

  if (!userData) return;

  try {
    const notification = {
      userId,
      type: 'system',
      title: 'Welcome to TestYourself! 🎉',
      message: `Hi ${userData.displayName || 'there'}! Get started by taking your first quiz and track your learning progress.`,
      read: false,
      createdAt: new Date()
    };

    await db.collection('notifications').add(notification);
  } catch (error) {
    console.error('Error sending welcome notification:', error);
  }
});

/**
 * SCHEDULED NOTIFICATION FUNCTIONS
 */

// Schedule daily study reminders
export const scheduleStudyReminders = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { uid } = request.auth;
  const { reminderTime, frequency } = request.data;

  try {
    // Store scheduled notification in Firestore
    const scheduledNotification = {
      userId: uid,
      type: 'study_reminder',
      title: 'Study Time! 📖',
      message: 'Keep up your learning streak! Time to study.',
      scheduledFor: new Date(reminderTime),
      frequency: frequency || 'daily',
      active: true,
      createdAt: new Date()
    };

    await db.collection('scheduled_notifications').add(scheduledNotification);
    return { success: true, message: 'Study reminder scheduled successfully' };
  } catch (error) {
    console.error('Error scheduling study reminder:', error);
    throw new HttpsError('internal', 'Failed to schedule study reminder');
  }
});

// Schedule quiz reminders
export const scheduleQuizReminder = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { uid } = request.auth;
  const { quizId, reminderTime, quizTitle } = request.data;

  try {
    const scheduledNotification = {
      userId: uid,
      type: 'quiz_reminder',
      title: 'Quiz Reminder 📚',
      message: `Time to take "${quizTitle}"!`,
      scheduledFor: new Date(reminderTime),
      data: { quizId },
      active: true,
      createdAt: new Date()
    };

    await db.collection('scheduled_notifications').add(scheduledNotification);
    return { success: true, message: 'Quiz reminder scheduled successfully' };
  } catch (error) {
    console.error('Error scheduling quiz reminder:', error);
    throw new HttpsError('internal', 'Failed to schedule quiz reminder');
  }
});

// Send push notification
export const sendPushNotification = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { targetUserId, title, body, data, imageUrl } = request.data;

  try {
    // Get user's FCM token
    const userDoc = await db.collection('users').doc(targetUserId).get();
    const userData = userDoc.data();

    if (!userData?.preferences?.notifications?.fcmToken) {
      throw new HttpsError('not-found', 'User FCM token not found');
    }

    const message = {
      token: userData.preferences.notifications.fcmToken,
      notification: {
        title,
        body,
        imageUrl
      },
      data: data || {},
      android: {
        notification: {
          icon: 'ic_notification',
          color: '#3b82f6',
          sound: 'default',
          clickAction: 'FLUTTER_NOTIFICATION_CLICK'
        }
      },
      apns: {
        payload: {
          aps: {
            sound: 'default',
            badge: 1
          }
        }
      }
    };

    // Send using Firebase Admin SDK (you'll need to import and configure)
    // const response = await admin.messaging().send(message);
    
    // For now, store as in-app notification
    await db.collection('notifications').add({
      userId: targetUserId,
      type: data?.type || 'general',
      title,
      message: body,
      data: data || {},
      read: false,
      createdAt: new Date()
    });

    return { success: true, message: 'Notification sent successfully' };
  } catch (error) {
    console.error('Error sending push notification:', error);
    throw new HttpsError('internal', 'Failed to send push notification');
  }
});

// Process scheduled notifications (run every minute)
export const processScheduledNotifications = onCall(async (request) => {
  try {
    const now = new Date();
    const scheduledQuery = await db.collection('scheduled_notifications')
      .where('active', '==', true)
      .where('scheduledFor', '<=', now)
      .get();

    const batch = db.batch();
    const notifications = [];

    for (const doc of scheduledQuery.docs) {
      const data = doc.data();
      
      // Create notification
      const notification = {
        userId: data.userId,
        type: data.type,
        title: data.title,
        message: data.message,
        data: data.data || {},
        read: false,
        createdAt: new Date()
      };

      notifications.push(notification);

      // Add to batch
      const notificationRef = db.collection('notifications').doc();
      batch.set(notificationRef, notification);

      // Update scheduled notification
      if (data.frequency === 'daily') {
        // Reschedule for next day
        const nextDay = new Date(data.scheduledFor);
        nextDay.setDate(nextDay.getDate() + 1);
        batch.update(doc.ref, { scheduledFor: nextDay });
      } else if (data.frequency === 'weekly') {
        // Reschedule for next week
        const nextWeek = new Date(data.scheduledFor);
        nextWeek.setDate(nextWeek.getDate() + 7);
        batch.update(doc.ref, { scheduledFor: nextWeek });
      } else {
        // One-time notification, deactivate
        batch.update(doc.ref, { active: false, processedAt: new Date() });
      }
    }

    await batch.commit();
    
    return { 
      success: true, 
      processed: notifications.length,
      notifications: notifications.map(n => ({ type: n.type, userId: n.userId }))
    };
  } catch (error) {
    console.error('Error processing scheduled notifications:', error);
    throw new HttpsError('internal', 'Failed to process scheduled notifications');
  }
});

/**
 * UTILITY FUNCTIONS
 */

async function updateUserStats(userId: string, quizResult: {
  totalQuestions: number;
  correctAnswers: number;
  timeSpent: number;
  score: number;
  subject: string;
}) {
  const userRef = db.collection('users').doc(userId);
  const userDoc = await userRef.get();
  
  if (!userDoc.exists) return;
  
  const userData = userDoc.data()!;
  const currentStats = userData.stats || {};

  const newTotalQuestions = (currentStats.totalQuestionsAnswered || 0) + quizResult.totalQuestions;
  const newCorrectAnswers = (currentStats.correctAnswers || 0) + quizResult.correctAnswers;
  const newAccuracy = (newCorrectAnswers / newTotalQuestions) * 100;

  const updatedStats = {
    ...currentStats,
    totalQuizzesCompleted: (currentStats.totalQuizzesCompleted || 0) + 1,
    totalQuestionsAnswered: newTotalQuestions,
    correctAnswers: newCorrectAnswers,
    accuracy: newAccuracy,
    totalTimeSpent: (currentStats.totalTimeSpent || 0) + quizResult.timeSpent,
    experiencePoints: (currentStats.experiencePoints || 0) + quizResult.score
  };

  // Add subject to favorites if not already there
  const favoriteSubjects = currentStats.favoriteSubjects || [];
  if (!favoriteSubjects.includes(quizResult.subject)) {
    favoriteSubjects.push(quizResult.subject);
  }
  updatedStats.favoriteSubjects = favoriteSubjects;

  await userRef.update({
    stats: updatedStats,
    updatedAt: new Date()
  });
}

async function updateQuizStats(quizId: string, score: number, maxScore: number) {
  const quizRef = db.collection('quizzes').doc(quizId);
  const quizDoc = await quizRef.get();
  
  if (!quizDoc.exists) return;
  
  const quizData = quizDoc.data()!;
  const currentAttempts = quizData.attempts || 0;
  const currentAverageScore = quizData.averageScore || 0;
  
  const newAttempts = currentAttempts + 1;
  const scorePercentage = (score / maxScore) * 100;
  const newAverageScore = ((currentAverageScore * currentAttempts) + scorePercentage) / newAttempts;

  await quizRef.update({
    attempts: newAttempts,
    averageScore: newAverageScore,
    updatedAt: new Date()
  });
}

/**
 * API ROUTES
 */

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Export the API
export const api = onRequest(app);